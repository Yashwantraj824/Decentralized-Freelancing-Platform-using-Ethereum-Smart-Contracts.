// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract FreelanceEscrow {
    address public employer;
    address public freelancer;
    string public jobDescription;
    uint256 public budget;
    bool public isCompleted;
    bool public isPaid;
    
    event ProjectStarted(address indexed freelancer);
    event WorkCompleted(address indexed freelancer);
    event PaymentReleased(address indexed freelancer, uint256 amount);
    
    constructor(address _freelancer, string memory _jobDescription) payable {
        require(_freelancer != address(0), "Invalid freelancer address");
        require(bytes(_jobDescription).length > 0, "Job description cannot be empty");
        require(msg.value > 0, "Budget must be greater than 0");
        
        employer = msg.sender;
        freelancer = _freelancer;
        jobDescription = _jobDescription;
        budget = msg.value;
        isCompleted = false;
        isPaid = false;
    }
    
    modifier onlyEmployer() {
        require(msg.sender == employer, "Only employer can call this function");
        _;
    }
    
    modifier onlyFreelancer() {
        require(msg.sender == freelancer, "Only freelancer can call this function");
        _;
    }
    
    function startProject() public onlyFreelancer {
        emit ProjectStarted(freelancer);
    }
    
    function completeWork() public onlyFreelancer {
        require(!isCompleted, "Work already completed");
        isCompleted = true;
        emit WorkCompleted(freelancer);
    }
    
    function releasePayment() public onlyEmployer {
        require(isCompleted, "Work must be completed before payment");
        require(!isPaid, "Payment already released");
        
        isPaid = true;
        uint256 amount = address(this).balance;
        
        emit PaymentReleased(freelancer, amount);
        payable(freelancer).transfer(amount);
    }
    
    function getProjectStatus() public view returns (string memory) {
        if (isPaid) return "Paid";
        if (isCompleted) return "Completed";
        return "In Progress";
    }
    
    function getContractBalance() public view returns (uint256) {
        return address(this).balance;
    }
    
    function getContractDetails() public view returns (
        address _employer,
        address _freelancer,
        string memory _jobDescription,
        uint256 _budget,
        bool _isCompleted,
        bool _isPaid,
        uint256 _balance
    ) {
        return (
            employer,
            freelancer,
            jobDescription,
            budget,
            isCompleted,
            isPaid,
            address(this).balance
        );
    }
}