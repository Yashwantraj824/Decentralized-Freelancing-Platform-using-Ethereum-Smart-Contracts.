import subprocess
import re

def get_ganache_private_keys():
    """Runs Ganache CLI and extracts private keys dynamically."""
    result = subprocess.run(["ganache", "-d"], capture_output=True, text=True)
    output = result.stdout

    # Regex to extract private keys
    private_keys = re.findall(r'Private Key: (0x[0-9a-fA-F]+)', output)
    return private_keys

private_keys = get_ganache_private_keys()
print(private_keys)
 