import streamlit as st
import sqlite3
import hashlib
from blockchain_interface import BlockchainInterface
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Initialize BlockchainInterface
blockchain = BlockchainInterface(provider_url='http://127.0.0.1:8545')  # Use Ganache or a testnet

# Database setup
def init_db():
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()

    # Create users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                user_type TEXT NOT NULL,
                wallet_address TEXT,
                private_key TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # Create freelancer_profiles table
    c.execute('''CREATE TABLE IF NOT EXISTS freelancer_profiles
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                skills TEXT NOT NULL,
                experience INTEGER,
                hourly_rate REAL,
                bio TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id))''')

    # Create projects table
    c.execute('''CREATE TABLE IF NOT EXISTS projects
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                employer_id INTEGER,
                freelancer_id INTEGER,
                status TEXT DEFAULT 'open',
                budget REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                contract_address TEXT,
                FOREIGN KEY (employer_id) REFERENCES users(id),
                FOREIGN KEY (freelancer_id) REFERENCES users(id))''')

    conn.commit()
    conn.close()

# Initialize database
init_db()

# Helper functions
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_user(username, password, email, user_type, wallet_address, private_key):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    try:
        hashed_password = hash_password(password)
        c.execute('''INSERT INTO users (username, password, email, user_type, wallet_address, private_key)
                     VALUES (?, ?, ?, ?, ?, ?)''', 
                  (username, hashed_password, email, user_type, wallet_address, private_key))
        user_id = c.lastrowid
        conn.commit()
        return user_id
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def verify_user(email, password):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    hashed_password = hash_password(password)
    c.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, hashed_password))
    user = c.fetchone()
    conn.close()
    return user

def create_freelancer_profile(user_id, skills, experience, hourly_rate, bio):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    c.execute('''INSERT INTO freelancer_profiles (user_id, skills, experience, hourly_rate, bio)
                VALUES (?, ?, ?, ?, ?)''', (user_id, skills, experience, hourly_rate, bio))
    conn.commit()
    conn.close()

def get_freelancer_profile(user_id):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    c.execute('SELECT * FROM freelancer_profiles WHERE user_id = ?', (user_id,))
    profile = c.fetchone()
    conn.close()
    return profile

def create_project(title, description, employer_id, budget):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    c.execute('''INSERT INTO projects (title, description, employer_id, budget)
                VALUES (?, ?, ?, ?)''', (title, description, employer_id, budget))
    project_id = c.lastrowid
    conn.commit()
    conn.close()
    return project_id

def get_projects(employer_id=None, freelancer_id=None, status='open'):
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()

    if employer_id:
        c.execute('SELECT * FROM projects WHERE employer_id = ?', (employer_id,))
    elif freelancer_id:
        c.execute('SELECT * FROM projects WHERE freelancer_id = ?', (freelancer_id,))
    else:
        c.execute('SELECT * FROM projects WHERE status = ?', (status,))

    projects = c.fetchall()
    conn.close()
    return projects

def get_all_freelancers():
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    c.execute('''SELECT users.id, users.username, users.email, freelancer_profiles.skills, 
                freelancer_profiles.experience, freelancer_profiles.hourly_rate, 
                freelancer_profiles.bio, users.wallet_address
                FROM users 
                JOIN freelancer_profiles ON users.id = freelancer_profiles.user_id
                WHERE users.user_type = 'freelancer'
                ''')
    freelancers = c.fetchall()
    conn.close()
    return freelancers

def match_freelancers(project_description, required_skills):
    freelancers = get_all_freelancers()
    if not freelancers:
        return []

    project_text = f"{project_description} {required_skills}"
    texts = [project_text]
    freelancer_data = []

    for freelancer in freelancers:
        freelancer_text = f"{freelancer[3]} {freelancer[6]}"
        texts.append(freelancer_text)
        freelancer_data.append({
            'id': freelancer[0],
            'username': freelancer[1],
            'email': freelancer[2],
            'skills': freelancer[3],
            'experience': freelancer[4],
            'hourly_rate': freelancer[5],
            'bio': freelancer[6],
            'wallet_address': freelancer[7]
        })

    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = vectorizer.fit_transform(texts)
    cosine_similarities = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])

    for idx, score in enumerate(cosine_similarities[0]):
        freelancer_data[idx]['match_score'] = score

    matched_freelancers = sorted(freelancer_data, key=lambda x: x['match_score'], reverse=True)
    return matched_freelancers

# Streamlit UI
st.set_page_config(page_title="Blockchain Freelancing Platform", layout="wide")

if 'user' not in st.session_state:
    st.session_state.user = None
if 'page' not in st.session_state:
    st.session_state.page = 'home'

def sidebar_navigation():
    if st.session_state.user:
        st.sidebar.title("Navigation")
        user_type = st.session_state.user[4]

        if user_type == 'employer':
            options = ["Post Project", "My Projects", "Find Freelancers", "Wallet"]
        else:
            options = ["My Profile", "Available Projects", "My Projects", "Wallet"]

        choice = st.sidebar.selectbox("Menu", options)

        if st.sidebar.button("Logout"):
            st.session_state.user = None
            st.session_state.page = 'home'
            st.rerun()

        return choice

def home_page():
    st.title("Blockchain-Based Freelancing Platform")

    col1, col2 = st.columns(2)

    with col1:
        st.header("New User?")
        user_type = st.selectbox("Select User Type", ["Employer", "Freelancer"])
        if st.button("Register"):
            st.session_state.page = 'register'
            st.session_state.registration_type = user_type.lower()
            st.rerun()

    with col2:
        st.header("Existing User?")
        if st.button("Login"):
            st.session_state.page = 'login'
            st.rerun()
from eth_account import Account

def validate_wallet_credentials(wallet_address, private_key):
    """Ensure the entered private key corresponds to the wallet address."""
    try:
        account = Account.from_key(private_key)
        return account.address.lower() == wallet_address.lower()
    except Exception:
        return False

def register_page():
    st.title("Registration")
    user_type = st.session_state.registration_type

    with st.form(f"{user_type}_registration"):
        st.subheader(f"{user_type.capitalize()} Registration")

        username = st.text_input("Username")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")

        # New fields for Wallet Address and Private Key
        wallet_address = st.text_input("Wallet Address (From Ganache)")
        private_key = st.text_input("Private Key (Matching the Wallet Address)", type="password")

        if user_type == 'freelancer':
            skills = st.text_input("Skills (comma-separated)")
            experience = st.number_input("Years of Experience", min_value=0)
            hourly_rate = st.number_input("Hourly Rate ($)", min_value=0)
            bio = st.text_area("Bio")

        if st.form_submit_button("Register"):
            if password != confirm_password:
                st.error("Passwords don't match!")
                return
            
            # Validate Private Key Matches Address
            if not validate_wallet_credentials(wallet_address, private_key):
                st.error("Invalid Wallet Address or Private Key!")
                return

            # Store user with manually entered wallet details
            user_id = create_user(username, password, email, user_type, wallet_address, private_key)

            if user_id:
                if user_type == 'freelancer':
                    create_freelancer_profile(user_id, skills, experience, hourly_rate, bio)
                st.success("Registration successful! Please login.")
                st.session_state.page = 'login'
                st.rerun()
            else:
                st.error("Username or email already exists!")


def login_page():
    st.title("Login")

    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")

        if st.form_submit_button("Login"):
            user = verify_user(email, password)
            if user:
                st.session_state.user = user
                st.session_state.page = 'dashboard'
                st.rerun()
            else:
                st.error("Invalid credentials!")

def post_project():
    st.subheader("Post New Project")

    with st.form("project_form"):
        title = st.text_input("Project Title")
        description = st.text_area("Project Description")
        budget = st.number_input("Budget ($)", min_value=0.0)

        if st.form_submit_button("Post Project"):
            project_id = create_project(title, description, st.session_state.user[0], budget)
            if project_id:
                st.success("Project posted successfully!")
def show_tx_hash(tx):
    st.info(f"**Tx Hash:** `{tx.transactionHash.hex()}`")

def view_projects(employer_id=None, freelancer_id=None):
    projects = get_projects(employer_id, freelancer_id)

    for project in projects:
        with st.expander(f"📁 {project[1]}"):
            st.markdown(f"**📝 Description:** {project[2]}")
            st.markdown(f"**💵 Budget:** ${project[6]}")
            st.markdown(f"**📊 Status:** `{project[5]}`")

            # Smart Contract Details
            if project[7]:
                try:
                    status = blockchain.get_contract_status(project[8])
                    st.markdown("### 🔐 Smart Contract")
                    st.code(f"Address: {project[8]}")
                    
                    st.write(f"👔 Employer: {status['employer']}")
                    st.write(f"👷 Freelancer: {status['freelancer']}")
                    st.write(f"✅ Work Completed: {status['is_completed']}")
                    st.write(f"💸 Payment Released: {status['is_paid']}")
                    st.write(f"📡 Status Code: {status['status']}")
                except Exception as e:
                    st.warning(f"⚠️ Failed to fetch contract status: {str(e)}")

            # Freelancer options
            if st.session_state.user[4] == 'freelancer':
                is_assigned = project[5] == 'assigned' and project[4] == st.session_state.user[0]
                if project[5] == 'open':
                    if st.button("📩 Apply", key=f"apply_{project[0]}"):
                        conn = sqlite3.connect('freelance_platform.db')
                        c = conn.cursor()
                        c.execute('UPDATE projects SET freelancer_id = ?, status = ? WHERE id = ?',
                                  (st.session_state.user[0], 'assigned', project[0]))
                        conn.commit()
                        conn.close()
                        st.success("✅ Applied successfully!")
                        st.rerun()

                if is_assigned:
                    if st.button("🚀 Start Project", key=f"start_{project[0]}"):
                        try:
                            tx = blockchain.start_project(project[8], st.session_state.user[6])
                            show_tx_hash(tx)
                            st.success("Project started!")
                        except Exception as e:
                            st.error(f"Failed to start: {str(e)}")

                    if st.button("✅ Mark as Completed", key=f"complete_{project[0]}"):
                        try:
                            tx = blockchain.complete_work(project[8], st.session_state.user[6])
                            conn = sqlite3.connect('freelance_platform.db')
                            c = conn.cursor()
                            c.execute('UPDATE projects SET status = ? WHERE id = ?', ('completed', project[0]))
                            conn.commit()
                            conn.close()
                            show_tx_hash(tx)
                            st.success("🎉 Work marked as completed!")
                        except Exception as e:
                            st.error(f"Failed to complete job: {str(e)}")

            # Employer: Release Payment
            if st.session_state.user[4] == 'employer' and project[5] == 'completed' and project[3] == st.session_state.user[0]:
                if st.button("💸 Release Payment", key=f"release_{project[0]}"):
                    try:
                        tx = blockchain.release_payment(project[8], st.session_state.user[6])
                        conn = sqlite3.connect('freelance_platform.db')
                        c = conn.cursor()
                        c.execute('UPDATE projects SET status = ? WHERE id = ?', ('paid', project[0]))
                        conn.commit()
                        conn.close()
                        show_tx_hash(tx)
                        st.success("✅ Payment released to freelancer!")
                    except Exception as e:
                        st.error(f"❌ Payment failed: {str(e)}")
# Add at the top with other session state initializations
if 'refresh_projects' not in st.session_state:
    st.session_state.refresh_projects = False
def find_freelancers_page():
    st.subheader("Find Freelancers")

    # Preserve search parameters across reruns
    if 'search_params' not in st.session_state:
        st.session_state.search_params = {
            'project_id': None,
            'description': '',
            'skills': ''
        }

    # Project selection
    projects = get_projects(employer_id=st.session_state.user[0], status='open')
    if not projects:
        st.warning("You have no open projects. Please post a project first.")
        return

    project_options = {p[0]: p[1] for p in projects}
    selected_project_id = st.selectbox(
        "Select a Project to Hire For",
        options=list(project_options.keys()),
        format_func=lambda x: project_options[x],
        key='project_select'
    )

    # Update session state when project changes
    if st.session_state.search_params['project_id'] != selected_project_id:
        st.session_state.search_params = {
            'project_id': selected_project_id,
            'description': next(p[2] for p in projects if p[0] == selected_project_id),
            'skills': ''
        }

    # Editable search fields
    project_description = st.text_area(
        "Project Description",
        value=st.session_state.search_params['description'],
        key='project_desc'
    )
    required_skills = st.text_input(
        "Required Skills",
        value=st.session_state.search_params['skills'],
        key='project_skills'
    )

    # Update session state on search
    if st.button("Find Matches"):
        st.session_state.search_params.update({
            'description': project_description,
            'skills': required_skills
        })
        st.session_state.refresh_projects = True

    # Display results
    if st.session_state.refresh_projects:
        show_freelancer_matches(selected_project_id, project_description, required_skills)

def show_freelancer_matches(project_id, description, skills):
    matched_freelancers = match_freelancers(description, skills)
    
    if not matched_freelancers:
        st.info("No freelancers found matching your requirements.")
        return

    st.write("### Matched Freelancers")
    
    for freelancer in matched_freelancers:
        with st.container():
            col1, col2, col3 = st.columns([3, 2, 1])
            with col1:
                st.markdown(f"**{freelancer['username']}**  \n"
                            f"Skills: {freelancer['skills']}  \n"
                            f"Experience: {freelancer['experience']} yrs  \n" 
                            f"Rate: ${freelancer['hourly_rate']}/hr")
            
            with col2:
                st.markdown(f"Match Score: {freelancer['match_score']*100:.1f}%  \n"
                            f"Wallet: `{freelancer['wallet_address']}`")
            
            with col3:
                if st.button(
                    "Hire",
                    key=f"hire_{freelancer['id']}_{project_id}",
                    use_container_width=True
                ):
                    handle_hire_action(project_id, freelancer)

def handle_hire_action(project_id, freelancer):
    try:
        # Get project details
        conn = sqlite3.connect('freelance_platform.db')
        c = conn.cursor()
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        project = c.fetchone()
        
        if not project:
            st.error("Project not found!")
            return

        # Deploy smart contract
        contract_address = blockchain.deploy_contract(
            employer_private_key=st.session_state.user[6],
            freelancer_address=freelancer['wallet_address'],
            job_description=project[2],  # project description
            amount=project[6]  # project budget
        )

        # Update project in database
        c.execute('''UPDATE projects 
                    SET freelancer_id = ?, 
                        status = ?, 
                        contract_address = ? 
                    WHERE id = ?''',
                (freelancer['id'], 'assigned', contract_address, project_id))
        conn.commit()
        
        # Update session state
        st.session_state.refresh_projects = False
        st.success(f"Hired {freelancer['username']}! Contract: {contract_address}")
        
        # Force refresh the UI
        st.rerun()
    
    except sqlite3.Error as e:
        st.error(f"Database error: {str(e)}")
    except Exception as e:
        st.error(f"Contract deployment failed: {str(e)}")
    finally:
        conn.close()

def wallet_page():
    st.subheader("Wallet")

    wallet_address = st.session_state.user[5]
    private_key = st.session_state.user[6]

    if wallet_address:
        # Convert the address to checksum format
        checksum_address = blockchain.w3.to_checksum_address(wallet_address)
        
        st.write("### Your Wallet Details")
        st.code(f"Address: {checksum_address}")
        st.code(f"Private Key: {private_key}")

        # Get balance using the checksum address
        balance = blockchain.w3.eth.get_balance(checksum_address)
        st.write(f"Balance: {blockchain.w3.from_wei(balance, 'ether')} ETH")

def main():
    if st.session_state.page == 'home':
        home_page()
    elif st.session_state.page == 'register':
        register_page()
    elif st.session_state.page == 'login':
        login_page()
    elif st.session_state.page == 'dashboard':
        choice = sidebar_navigation()
        wallet_address = st.session_state.user[5]  # Employer's wallet address
        balance_wei = blockchain.w3.eth.get_balance(wallet_address)
        balance_eth = blockchain.w3.from_wei(balance_wei, 'ether')
       # st.write(f"Employer Wallet Balance: {wallet_address} ETH")

        #st.write(f"Employer Wallet Balance: {balance_eth} ETH")

        # if balance_eth < 0.01:  # Set a minimum balance threshold
        #     st.error("⚠️ Insufficient funds! Add ETH to your wallet before proceeding.")
        #     st.stop()

        if not choice:
            return

        if choice == "Post Project":
            post_project()
        elif choice in ["My Projects", "Available Projects"]:
            if st.session_state.user[4] == 'employer':
                view_projects(employer_id=st.session_state.user[0])
            else:
                view_projects(freelancer_id=st.session_state.user[0])
        elif choice == "Find Freelancers":
            find_freelancers_page()
        elif choice == "Wallet":
            wallet_page()
        elif choice == "My Profile":
            st.subheader("My Profile")
            profile = get_freelancer_profile(st.session_state.user[0])
            if profile:
                st.write(f"Skills: {profile[2]}")
                st.write(f"Experience: {profile[3]} years")
                st.write(f"Hourly Rate: ${profile[4]}/hour")
                st.write(f"Bio: {profile[5]}")

if __name__ == "__main__":
    main()