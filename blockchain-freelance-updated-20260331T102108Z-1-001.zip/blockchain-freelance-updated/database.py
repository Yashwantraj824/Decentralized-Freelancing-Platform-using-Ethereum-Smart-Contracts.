import sqlite3

def init_db():
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()

    # Create users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                user_type TEXT NOT NULL,
                wallet_address TEXT,
                private_key TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # Create freelancer_profiles table
    c.execute('''CREATE TABLE IF NOT EXISTS freelancer_profiles
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                skills TEXT NOT NULL,
                experience INTEGER,
                hourly_rate REAL,
                bio TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id))''')

    # Create projects table
    c.execute('''CREATE TABLE IF NOT EXISTS projects
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                employer_id INTEGER,
                freelancer_id INTEGER,
                status TEXT DEFAULT 'open',
                budget REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                contract_address TEXT,
                FOREIGN KEY (employer_id) REFERENCES users(id),
                FOREIGN KEY (freelancer_id) REFERENCES users(id))''')

    conn.commit()
    conn.close()

# Initialize database
init_db()