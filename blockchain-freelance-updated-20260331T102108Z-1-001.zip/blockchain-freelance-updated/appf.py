from fastapi import FastAPI, HTTPException, Depends, File, UploadFile, Form, Path as PathParam, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
import sqlite3
import hashlib
import uvicorn
from datetime import datetime
from blockchain_interface import BlockchainInterface
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from eth_account import Account
import os
import json
import base64
from pathlib import Path
import asyncio

# Initialize FastAPI app
app = FastAPI(
    title="Blockchain Freelancing Platform API",
    description="API for blockchain-based freelancing platform",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize BlockchainInterface
blockchain = BlockchainInterface(provider_url='http://127.0.0.1:8545')

# Create uploads directory if it doesn't exist
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# WebSocket Connection Manager for real-time messaging
class ConnectionManager:
    def __init__(self):
        # Store active connections: {project_id: {user_id: websocket}}
        self.active_connections: Dict[int, Dict[int, WebSocket]] = {}

    async def connect(self, websocket: WebSocket, project_id: int, user_id: int):
        await websocket.accept()
        if project_id not in self.active_connections:
            self.active_connections[project_id] = {}
        self.active_connections[project_id][user_id] = websocket
        print(f"User {user_id} connected to project {project_id}")

    def disconnect(self, project_id: int, user_id: int):
        if project_id in self.active_connections:
            if user_id in self.active_connections[project_id]:
                del self.active_connections[project_id][user_id]
                print(f"User {user_id} disconnected from project {project_id}")
            if not self.active_connections[project_id]:
                del self.active_connections[project_id]

    async def send_message_to_project(self, project_id: int, message: dict, sender_id: int):
        """Send message to all users in the project except the sender"""
        if project_id in self.active_connections:
            for user_id, websocket in self.active_connections[project_id].items():
                if user_id != sender_id:  # Don't send back to sender
                    try:
                        await websocket.send_json(message)
                    except Exception as e:
                        print(f"Error sending message to user {user_id}: {e}")

manager = ConnectionManager()

# Pydantic models
class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str
    user_type: str
    wallet_address: str
    private_key: str
    # Freelancer specific fields
    skills: Optional[str] = None
    experience: Optional[int] = 0
    hourly_rate: Optional[float] = 0
    bio: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class ProjectCreate(BaseModel):
    title: str
    description: str
    budget: float
    employer_id: int
    required_skills: Optional[str] = None
    timeline: Optional[str] = None
    requirements: Optional[str] = None
    budget_breakdown: Optional[str] = None

class ProjectUpdate(BaseModel):
    freelancer_id: Optional[int] = None
    status: Optional[str] = None
    contract_address: Optional[str] = None
    completion_files: Optional[str] = None
    completion_notes: Optional[str] = None
    budget_breakdown: Optional[str] = None
    revision_request: Optional[str] = None
    revision_count: Optional[int] = None

class ProjectAction(BaseModel):
    reason: Optional[str] = None
    note: Optional[str] = None

class FreelancerProfileCreate(BaseModel):
    user_id: int
    skills: str
    experience: int
    hourly_rate: float
    bio: Optional[str] = None

class FreelancerProfileUpdate(BaseModel):
    skills: Optional[str] = None
    experience: Optional[int] = None
    hourly_rate: Optional[float] = None
    bio: Optional[str] = None

class FreelancerMatchRequest(BaseModel):
    project_description: str
    required_skills: str

class ContractDeploy(BaseModel):
    employer_private_key: str
    freelancer_address: str
    job_description: str
    amount: float

class ContractAction(BaseModel):
    contract_address: str
    action: str
    private_key: str

class MessageCreate(BaseModel):
    project_id: int
    sender_id: int
    message_text: Optional[str] = None
    file_url: Optional[str] = None
    file_name: Optional[str] = None

class MessageMarkRead(BaseModel):
    message_ids: List[int]

# Database setup
def init_db():
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()

    # Create users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                user_type TEXT NOT NULL,
                wallet_address TEXT,
                private_key TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # Create freelancer_profiles table
    c.execute('''CREATE TABLE IF NOT EXISTS freelancer_profiles
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                skills TEXT NOT NULL,
                experience INTEGER,
                hourly_rate REAL,
                bio TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id))''')

    # Create projects table
    c.execute('''CREATE TABLE IF NOT EXISTS projects
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                employer_id INTEGER,
                freelancer_id INTEGER,
                status TEXT DEFAULT 'open',
                budget REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                contract_address TEXT,
                required_skills TEXT,
                timeline TEXT,
                requirements TEXT,
                completion_files TEXT,
                completion_notes TEXT,
                budget_breakdown TEXT,
                media_files TEXT,
                revision_request TEXT,
                revision_count INTEGER DEFAULT 0,
                FOREIGN KEY (employer_id) REFERENCES users(id),
                FOREIGN KEY (freelancer_id) REFERENCES users(id))''')

    # Add completion_files and completion_notes columns if they don't exist (for existing databases)
    try:
        c.execute("ALTER TABLE projects ADD COLUMN completion_files TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        c.execute("ALTER TABLE projects ADD COLUMN completion_notes TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        c.execute("ALTER TABLE projects ADD COLUMN budget_breakdown TEXT")
    except sqlite3.OperationalError:
        pass

    try:
        c.execute("ALTER TABLE projects ADD COLUMN media_files TEXT")
    except sqlite3.OperationalError:
        pass

    try:
        c.execute("ALTER TABLE projects ADD COLUMN revision_request TEXT")
    except sqlite3.OperationalError:
        pass

    try:
        c.execute("ALTER TABLE projects ADD COLUMN revision_count INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    # Create messages table for project communication
    c.execute('''CREATE TABLE IF NOT EXISTS messages
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                message_text TEXT,
                file_url TEXT,
                file_name TEXT,
                is_read BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (sender_id) REFERENCES users(id))''')

    conn.commit()
    conn.close()

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    init_db()

# Helper functions
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def get_db_connection():
    conn = sqlite3.connect('freelance_platform.db')
    conn.row_factory = sqlite3.Row
    return conn

def row_to_dict(row) -> dict:
    return dict(row) if row else None

def validate_wallet_credentials(wallet_address: str, private_key: str) -> bool:
    """Ensure the entered private key corresponds to the wallet address."""
    try:
        account = Account.from_key(private_key)
        return account.address.lower() == wallet_address.lower()
    except Exception:
        return False

# Authentication endpoints
@app.post("/auth/register", response_model=dict)
async def register_user(user_data: UserRegister):
    # Validate wallet credentials
    if not validate_wallet_credentials(user_data.wallet_address, user_data.private_key):
        raise HTTPException(status_code=400, detail="Invalid Wallet Address or Private Key!")
    
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        hashed_password = hash_password(user_data.password)
        
        # Insert user
        c.execute('''INSERT INTO users (username, email, password, user_type, wallet_address, private_key)
                     VALUES (?, ?, ?, ?, ?, ?)''', 
                  (user_data.username, user_data.email, hashed_password, 
                   user_data.user_type, user_data.wallet_address, user_data.private_key))
        
        user_id = c.lastrowid
        
        # Create freelancer profile if needed
        if user_data.user_type == 'freelancer' and user_data.skills:
            c.execute('''INSERT INTO freelancer_profiles (user_id, skills, experience, hourly_rate, bio)
                         VALUES (?, ?, ?, ?, ?)''', 
                      (user_id, user_data.skills, user_data.experience, 
                       user_data.hourly_rate, user_data.bio))
        
        conn.commit()
        
        # Return user data
        c.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = row_to_dict(c.fetchone())
        user.pop('password')  # Remove password from response
        
        return user
        
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Username or email already exists!")
    finally:
        conn.close()

@app.post("/auth/verify", response_model=dict)
async def verify_user(login_data: UserLogin):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        hashed_password = hash_password(login_data.password)
        c.execute('SELECT * FROM users WHERE email = ? AND password = ?', 
                  (login_data.email, hashed_password))
        user = c.fetchone()
        
        if user:
            user_dict = row_to_dict(user)
            user_dict.pop('password')  # Remove password from response
            return user_dict
        else:
            raise HTTPException(status_code=401, detail="Invalid credentials!")
            
    finally:
        conn.close()

@app.post("/auth/validate-wallet", response_model=dict)
async def validate_wallet(wallet_data: dict):
    wallet_address = wallet_data.get('wallet_address')
    private_key = wallet_data.get('private_key')
    
    is_valid = validate_wallet_credentials(wallet_address, private_key)
    return {"valid": is_valid}

# Project endpoints
@app.get("/projects", response_model=List[dict])
async def get_projects(
    employer_id: Optional[int] = None, 
    freelancer_id: Optional[int] = None, 
    status: Optional[str] = None
):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        if employer_id:
            c.execute('SELECT * FROM projects WHERE employer_id = ? ORDER BY created_at DESC', (employer_id,))
        elif freelancer_id:
            c.execute('SELECT * FROM projects WHERE freelancer_id = ? ORDER BY created_at DESC', (freelancer_id,))
        elif status:
            c.execute('SELECT * FROM projects WHERE status = ? ORDER BY created_at DESC', (status,))
        else:
            c.execute('SELECT * FROM projects ORDER BY created_at DESC')
        
        projects = [row_to_dict(row) for row in c.fetchall()]
        return projects
        
    finally:
        conn.close()

@app.post("/projects", response_model=dict)
async def create_project(project_data: ProjectCreate):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        c.execute('''INSERT INTO projects (title, description, employer_id, budget, required_skills, timeline, requirements, budget_breakdown)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                  (project_data.title, project_data.description, project_data.employer_id,
                   project_data.budget, project_data.required_skills,
                   project_data.timeline, project_data.requirements,
                   project_data.budget_breakdown))
        
        project_id = c.lastrowid
        conn.commit()
        
        # Return created project
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        project = row_to_dict(c.fetchone())
        return project
        
    finally:
        conn.close()

# --- paste/replace the existing update_project endpoint in your FastAPI main.py ---
from fastapi import BackgroundTasks

@app.put("/projects/{project_id}", response_model=dict)
async def update_project(project_id: int, updates: ProjectUpdate, background_tasks: BackgroundTasks):
    conn = get_db_connection()
    c = conn.cursor()

    try:
        # Build dynamic update query
        update_fields = []
        values = []

        if updates.freelancer_id is not None:
            update_fields.append("freelancer_id = ?")
            values.append(updates.freelancer_id)

        if updates.status is not None:
            update_fields.append("status = ?")
            values.append(updates.status)

        if updates.contract_address is not None:
            update_fields.append("contract_address = ?")
            values.append(updates.contract_address)

        if updates.completion_files is not None:
            update_fields.append("completion_files = ?")
            values.append(updates.completion_files)

        if updates.completion_notes is not None:
            update_fields.append("completion_notes = ?")
            values.append(updates.completion_notes)

        if updates.budget_breakdown is not None:
            update_fields.append("budget_breakdown = ?")
            values.append(updates.budget_breakdown)

        if updates.revision_request is not None:
            update_fields.append("revision_request = ?")
            values.append(updates.revision_request)

        if updates.revision_count is not None:
            update_fields.append("revision_count = ?")
            values.append(updates.revision_count)

        if update_fields:
            values.append(project_id)
            query = f"UPDATE projects SET {', '.join(update_fields)} WHERE id = ?"
            c.execute(query, values)
            conn.commit()

        # Return updated project
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        project = c.fetchone()

        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        project_dict = row_to_dict(project)

        # If project was just assigned/pending and has no contract_address, deploy in background
        should_deploy = (
            project_dict.get('status') in ('assigned', 'pending')
            and (not project_dict.get('contract_address'))
            and project_dict.get('freelancer_id') is not None
            and project_dict.get('employer_id') is not None
        )

        if should_deploy:
            # schedule background deploy so response isn't blocked for long
            background_tasks.add_task(_deploy_and_save_contract, project_id)

        return project_dict

    finally:
        conn.close()
# main.py (FastAPI) - add endpoint
@app.post("/projects/{project_id}/deploy", response_model=dict)
async def deploy_project_endpoint(project_id: int = PathParam(..., gt=0)):
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        proj = c.fetchone()
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")
        project = row_to_dict(proj)

        # if already deployed return the address
        if project.get('contract_address'):
            return {"contract_address": project.get('contract_address')}

        # need employer private key and freelancer wallet
        employer_id = project.get('employer_id')
        freelancer_id = project.get('freelancer_id')

        if not employer_id or not freelancer_id:
            raise HTTPException(status_code=400, detail="Project missing employer or freelancer")

        c.execute('SELECT private_key FROM users WHERE id = ?', (employer_id,))
        emp = c.fetchone()
        if not emp:
            raise HTTPException(status_code=404, detail="Employer not found")
        employer_private_key = emp['private_key'] if isinstance(emp, sqlite3.Row) else emp[0]

        c.execute('SELECT wallet_address FROM users WHERE id = ?', (freelancer_id,))
        fr = c.fetchone()
        if not fr:
            raise HTTPException(status_code=404, detail="Freelancer not found")
        freelancer_wallet = fr['wallet_address'] if isinstance(fr, sqlite3.Row) else fr[0]

        if not employer_private_key or not freelancer_wallet:
            raise HTTPException(status_code=400, detail="Missing employer private key or freelancer wallet address")

        # deploy
        try:
            contract_address = blockchain.deploy_contract(
                employer_private_key=employer_private_key,
                freelancer_address=freelancer_wallet,
                job_description=project.get('description') or project.get('title') or 'job',
                amount=float(project.get('budget') or 0)
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

        # persist
        c.execute('UPDATE projects SET contract_address = ? WHERE id = ?', (contract_address, project_id))
        conn.commit()

        return {"contract_address": contract_address}

    finally:
        conn.close()


# Helper background task - deploy and save to DB
def _deploy_and_save_contract(project_id: int):
    """
    Background task: fetch project/employer/freelancer details, deploy contract,
    persist contract_address back to projects table.
    """
    conn = sqlite3.connect('freelance_platform.db')
    c = conn.cursor()
    try:
        # load project data
        c.execute('SELECT id, title, description, employer_id, freelancer_id, budget, contract_address FROM projects WHERE id = ?', (project_id,))
        proj = c.fetchone()
        if not proj:
            print(f"[auto-deploy] project {project_id} not found")
            return

        project = dict(zip([d[0] for d in c.description], proj)) if hasattr(c, 'description') else {
            'id': proj[0],'title': proj[1],'description': proj[2],'employer_id': proj[3],'freelancer_id': proj[4],'budget': proj[5],'contract_address': proj[6]
        }

        if project.get('contract_address'):
            print(f"[auto-deploy] project {project_id} already has contract_address: {project['contract_address']}")
            return

        # fetch employer private key
        c.execute('SELECT wallet_address, private_key FROM users WHERE id = ?', (project['employer_id'],))
        emp = c.fetchone()
        if not emp:
            print(f"[auto-deploy] employer {project['employer_id']} not found")
            return
        employer_wallet, employer_private_key = emp[0], emp[1]

        # fetch freelancer wallet address
        c.execute('SELECT wallet_address FROM users WHERE id = ?', (project['freelancer_id'],))
        fr = c.fetchone()
        if not fr:
            print(f"[auto-deploy] freelancer {project['freelancer_id']} not found")
            return
        freelancer_wallet = fr[0]

        if not employer_private_key or not freelancer_wallet:
            print(f"[auto-deploy] missing keys/wallets: emp_pk={bool(employer_private_key)} fr_wallet={bool(freelancer_wallet)}")
            return

        # call your blockchain interface deploy
        try:
            print(f"[auto-deploy] deploying contract for project {project_id} -> freelancer {freelancer_wallet}")
            contract_address = blockchain.deploy_contract(
                employer_private_key=employer_private_key,
                freelancer_address=freelancer_wallet,
                job_description=project.get('description') or project.get('title') or 'job',
                amount=float(project.get('budget') or 0)
            )
            if contract_address:
                # persist contract_address
                c.execute('UPDATE projects SET contract_address = ? WHERE id = ?', (contract_address, project_id))
                conn.commit()
                print(f"[auto-deploy] deployed and saved contract {contract_address} for project {project_id}")
            else:
                print(f"[auto-deploy] deploy returned no address for project {project_id}")
        except Exception as e:
            print(f"[auto-deploy] deploy failed for project {project_id}: {e}")

    except Exception as e:
        print(f"[auto-deploy] unexpected error for project {project_id}: {e}")
    finally:
        conn.close()


# Freelancer endpoints
@app.get("/freelancers", response_model=List[dict])
async def get_all_freelancers():
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        c.execute('''SELECT users.id, users.username, users.email, freelancer_profiles.skills, 
                    freelancer_profiles.experience, freelancer_profiles.hourly_rate, 
                    freelancer_profiles.bio, users.wallet_address
                    FROM users 
                    JOIN freelancer_profiles ON users.id = freelancer_profiles.user_id
                    WHERE users.user_type = 'freelancer'
                    ORDER BY freelancer_profiles.hourly_rate''')
        
        freelancers = [row_to_dict(row) for row in c.fetchall()]
        return freelancers
        
    finally:
        conn.close()

@app.get("/freelancers/profile/{user_id}", response_model=dict)
async def get_freelancer_profile(user_id: int):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        c.execute('SELECT * FROM freelancer_profiles WHERE user_id = ?', (user_id,))
        profile = c.fetchone()
        
        if profile:
            return row_to_dict(profile)
        else:
            raise HTTPException(status_code=404, detail="Profile not found")
            
    finally:
        conn.close()

@app.post("/freelancers/profile", response_model=dict)
async def create_freelancer_profile(profile_data: FreelancerProfileCreate):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        c.execute('''INSERT INTO freelancer_profiles (user_id, skills, experience, hourly_rate, bio)
                     VALUES (?, ?, ?, ?, ?)''', 
                  (profile_data.user_id, profile_data.skills, profile_data.experience, 
                   profile_data.hourly_rate, profile_data.bio))
        
        profile_id = c.lastrowid
        conn.commit()
        
        # Return created profile
        c.execute('SELECT * FROM freelancer_profiles WHERE id = ?', (profile_id,))
        profile = row_to_dict(c.fetchone())
        return profile
        
    finally:
        conn.close()

@app.put("/freelancers/profile/{user_id}", response_model=dict)
async def update_freelancer_profile(user_id: int, profile_data: FreelancerProfileUpdate):
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Build dynamic update query
        update_fields = []
        values = []
        
        if profile_data.skills is not None:
            update_fields.append("skills = ?")
            values.append(profile_data.skills)
            
        if profile_data.experience is not None:
            update_fields.append("experience = ?")
            values.append(profile_data.experience)
            
        if profile_data.hourly_rate is not None:
            update_fields.append("hourly_rate = ?")
            values.append(profile_data.hourly_rate)
            
        if profile_data.bio is not None:
            update_fields.append("bio = ?")
            values.append(profile_data.bio)
        
        if update_fields:
            values.append(user_id)
            query = f"UPDATE freelancer_profiles SET {', '.join(update_fields)} WHERE user_id = ?"
            c.execute(query, values)
            conn.commit()
        
        # Return updated profile
        c.execute('SELECT * FROM freelancer_profiles WHERE user_id = ?', (user_id,))
        profile = c.fetchone()
        
        if profile:
            return row_to_dict(profile)
        else:
            raise HTTPException(status_code=404, detail="Profile not found")
            
    finally:
        conn.close()

@app.post("/freelancers/match", response_model=List[dict])
async def match_freelancers(match_request: FreelancerMatchRequest):
    freelancers = await get_all_freelancers()
    
    if not freelancers:
        return []

    project_text = f"{match_request.project_description} {match_request.required_skills}"
    texts = [project_text]
    freelancer_data = []

    for freelancer in freelancers:
        freelancer_text = f"{freelancer.get('skills', '')} {freelancer.get('bio', '')}"
        texts.append(freelancer_text)
        freelancer_data.append({
            'id': freelancer['id'],
            'username': freelancer['username'],
            'email': freelancer['email'],
            'skills': freelancer['skills'],
            'experience': freelancer['experience'],
            'hourly_rate': freelancer['hourly_rate'],
            'bio': freelancer['bio'],
            'wallet_address': freelancer['wallet_address']
        })

    try:
        vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = vectorizer.fit_transform(texts)
        cosine_similarities = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])

        for idx, score in enumerate(cosine_similarities[0]):
            freelancer_data[idx]['match_score'] = float(score)

        matched_freelancers = sorted(freelancer_data, key=lambda x: x['match_score'], reverse=True)
        return matched_freelancers
    except Exception as e:
        # Fallback to simple keyword matching if TF-IDF fails
        for freelancer in freelancer_data:
            score = 0
            freelancer_skills = freelancer.get('skills', '').lower()
            required_skills_lower = match_request.required_skills.lower()
            
            # Simple keyword matching
            for skill in required_skills_lower.split(','):
                if skill.strip() in freelancer_skills:
                    score += 0.3
            
            freelancer['match_score'] = min(score, 1.0)
        
        return sorted(freelancer_data, key=lambda x: x['match_score'], reverse=True)

# Blockchain endpoints
@app.post("/blockchain/deploy", response_model=dict)
async def deploy_contract(contract_data: ContractDeploy):
    try:
        contract_address = blockchain.deploy_contract(
            employer_private_key=contract_data.employer_private_key,
            freelancer_address=contract_data.freelancer_address,
            job_description=contract_data.job_description,
            amount=contract_data.amount
        )
        
        return {"contract_address": contract_address}
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Contract deployment failed: {str(e)}")

@app.post("/blockchain/execute", response_model=dict)
async def execute_contract_action(action_data: ContractAction):
    try:
        if action_data.action == "start":
            tx_receipt = blockchain.start_project(action_data.contract_address, action_data.private_key)
        elif action_data.action == "complete":
            tx_receipt = blockchain.complete_work(action_data.contract_address, action_data.private_key)
        elif action_data.action == "release":
            tx_receipt = blockchain.release_payment(action_data.contract_address, action_data.private_key)
        else:
            raise HTTPException(status_code=400, detail="Invalid action")
        
        return {
            "transaction_hash": tx_receipt.transactionHash.hex(),
            "status": "success"
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Transaction failed: {str(e)}")

@app.get("/blockchain/status/{contract_address}", response_model=dict)
async def get_contract_status(contract_address: str):
    try:
        status = blockchain.get_contract_status(contract_address)
        return status
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to get contract status: {str(e)}")

# Wallet endpoints
@app.get("/wallet/balance/{address}", response_model=dict)
async def get_wallet_balance(address: str):
    try:
        checksum_address = blockchain.w3.to_checksum_address(address)
        balance_wei = blockchain.w3.eth.get_balance(checksum_address)
        balance_eth = blockchain.w3.from_wei(balance_wei, 'ether')
        
        return {
            "address": checksum_address,
            "balance_wei": str(balance_wei),
            "balance_eth": str(balance_eth)
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to get balance: {str(e)}")

# File upload endpoint
@app.post("/projects/{project_id}/upload-completion-files")
async def upload_completion_files(
    project_id: int = PathParam(..., gt=0),
    files: List[UploadFile] = File(...),
    notes: Optional[str] = Form(None)
):
    try:
        conn = get_db_connection()
        c = conn.cursor()

        # Check if project exists
        c.execute('SELECT id FROM projects WHERE id = ?', (project_id,))
        project = c.fetchone()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        # Create project-specific upload directory
        project_upload_dir = UPLOAD_DIR / str(project_id)
        project_upload_dir.mkdir(exist_ok=True)

        # Save files and collect file information
        uploaded_files = []
        for file in files:
            # Create unique filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_extension = Path(file.filename).suffix
            unique_filename = f"{timestamp}_{file.filename}"
            file_path = project_upload_dir / unique_filename

            # Save file
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)

            uploaded_files.append({
                "filename": file.filename,
                "stored_filename": unique_filename,
                "size": len(content),
                "content_type": file.content_type,
                "upload_date": datetime.now().isoformat()
            })

        # Store file information in database as JSON
        files_json = json.dumps(uploaded_files)
        c.execute(
            'UPDATE projects SET completion_files = ?, completion_notes = ? WHERE id = ?',
            (files_json, notes, project_id)
        )
        conn.commit()
        conn.close()

        return {
            "message": "Files uploaded successfully",
            "files": uploaded_files,
            "project_id": project_id
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

# Download/view uploaded file endpoint
@app.get("/projects/{project_id}/files/{filename}")
async def get_completion_file(project_id: int, filename: str):
    try:
        file_path = UPLOAD_DIR / str(project_id) / filename

        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")

        return FileResponse(
            path=file_path,
            filename=filename,
            media_type='application/octet-stream'
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve file: {str(e)}")

# Get project completion files metadata
@app.get("/projects/{project_id}/completion-files")
async def get_completion_files_metadata(project_id: int):
    try:
        conn = get_db_connection()
        c = conn.cursor()

        c.execute('SELECT completion_files, completion_notes FROM projects WHERE id = ?', (project_id,))
        result = c.fetchone()
        conn.close()

        if not result:
            raise HTTPException(status_code=404, detail="Project not found")

        completion_files = result[0] or result['completion_files'] if isinstance(result, sqlite3.Row) else result[0]
        completion_notes = result[1] or result['completion_notes'] if isinstance(result, sqlite3.Row) else result[1]

        files = json.loads(completion_files) if completion_files else []

        return {
            "files": files,
            "notes": completion_notes,
            "project_id": project_id
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve file metadata: {str(e)}")

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# ============ MESSAGING ENDPOINTS ============

# WebSocket endpoint for real-time messaging
@app.websocket("/ws/chat/{project_id}/{user_id}")
async def websocket_chat(websocket: WebSocket, project_id: int, user_id: int):
    await manager.connect(websocket, project_id, user_id)
    try:
        while True:
            # Keep connection alive and receive messages
            data = await websocket.receive_json()

            # Save message to database
            conn = get_db_connection()
            c = conn.cursor()
            try:
                c.execute('''INSERT INTO messages (project_id, sender_id, message_text, file_url, file_name)
                            VALUES (?, ?, ?, ?, ?)''',
                         (project_id, user_id, data.get('message_text'),
                          data.get('file_url'), data.get('file_name')))
                message_id = c.lastrowid
                conn.commit()

                # Get sender info
                c.execute('SELECT username FROM users WHERE id = ?', (user_id,))
                sender = c.fetchone()
                sender_name = sender['username'] if sender else 'Unknown'

                # Prepare message for broadcast
                message_data = {
                    'id': message_id,
                    'project_id': project_id,
                    'sender_id': user_id,
                    'sender_name': sender_name,
                    'message_text': data.get('message_text'),
                    'file_url': data.get('file_url'),
                    'file_name': data.get('file_name'),
                    'is_read': False,
                    'created_at': datetime.now().isoformat()
                }

                # Broadcast to other users in the project
                await manager.send_message_to_project(project_id, message_data, user_id)

            finally:
                conn.close()

    except WebSocketDisconnect:
        manager.disconnect(project_id, user_id)
    except Exception as e:
        print(f"WebSocket error: {e}")
        manager.disconnect(project_id, user_id)

# Get message history for a project
@app.get("/messages/{project_id}", response_model=List[dict])
async def get_project_messages(project_id: int, user_id: Optional[int] = None):
    conn = get_db_connection()
    c = conn.cursor()

    try:
        # Get all messages for the project with sender information
        c.execute('''SELECT m.id, m.project_id, m.sender_id, u.username as sender_name,
                    m.message_text, m.file_url, m.file_name, m.is_read, m.created_at
                    FROM messages m
                    JOIN users u ON m.sender_id = u.id
                    WHERE m.project_id = ?
                    ORDER BY m.created_at ASC''', (project_id,))

        messages = [row_to_dict(row) for row in c.fetchall()]

        # If user_id is provided, mark messages as read for this user
        if user_id:
            unread_message_ids = [m['id'] for m in messages if m['sender_id'] != user_id and not m['is_read']]
            if unread_message_ids:
                placeholders = ','.join('?' * len(unread_message_ids))
                c.execute(f'UPDATE messages SET is_read = 1 WHERE id IN ({placeholders})', unread_message_ids)
                conn.commit()

        return messages

    finally:
        conn.close()

# Get unread message count for a user across all projects
@app.get("/messages/unread/{user_id}", response_model=Dict[int, int])
async def get_unread_message_counts(user_id: int):
    conn = get_db_connection()
    c = conn.cursor()

    try:
        # Get projects where user is either employer or freelancer
        c.execute('''SELECT id FROM projects
                    WHERE employer_id = ? OR freelancer_id = ?''', (user_id, user_id))
        user_projects = [row['id'] for row in c.fetchall()]

        # Get unread count for each project
        unread_counts = {}
        for project_id in user_projects:
            c.execute('''SELECT COUNT(*) as count FROM messages
                        WHERE project_id = ? AND sender_id != ? AND is_read = 0''',
                     (project_id, user_id))
            count = c.fetchone()['count']
            if count > 0:
                unread_counts[project_id] = count

        return unread_counts

    finally:
        conn.close()

# Upload message file attachment
@app.post("/messages/{project_id}/upload-file")
async def upload_message_file(
    project_id: int,
    file: UploadFile = File(...)
):
    try:
        # Create message files directory
        message_files_dir = UPLOAD_DIR / "messages" / str(project_id)
        message_files_dir.mkdir(parents=True, exist_ok=True)

        # Create unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_extension = Path(file.filename).suffix
        unique_filename = f"{timestamp}_{file.filename}"
        file_path = message_files_dir / unique_filename

        # Save file
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)

        # Return file URL (relative path)
        file_url = f"/messages/{project_id}/files/{unique_filename}"

        return {
            "file_url": file_url,
            "file_name": file.filename,
            "size": len(content)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

# Download message file attachment
@app.get("/messages/{project_id}/files/{filename}")
async def get_message_file(project_id: int, filename: str):
    try:
        file_path = UPLOAD_DIR / "messages" / str(project_id) / filename

        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")

        return FileResponse(
            path=file_path,
            filename=filename,
            media_type='application/octet-stream'
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve file: {str(e)}")

# Upload project reference media
@app.post("/projects/{project_id}/upload-media")
async def upload_project_media(
    project_id: int = PathParam(..., gt=0),
    files: List[UploadFile] = File(...),
):
    try:
        conn = get_db_connection()
        c = conn.cursor()
        c.execute('SELECT id, media_files FROM projects WHERE id = ?', (project_id,))
        project = c.fetchone()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        media_upload_dir = UPLOAD_DIR / "media" / str(project_id)
        media_upload_dir.mkdir(parents=True, exist_ok=True)

        uploaded = []
        for file in files:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            unique_filename = f"{timestamp}_{file.filename}"
            file_path = media_upload_dir / unique_filename
            content = await file.read()
            with open(file_path, "wb") as buf:
                buf.write(content)
            uploaded.append({
                "filename": file.filename,
                "stored_filename": unique_filename,
                "size": len(content),
                "content_type": file.content_type,
                "upload_date": datetime.now().isoformat()
            })

        existing_raw = project['media_files'] if isinstance(project, sqlite3.Row) else project[1]
        existing = json.loads(existing_raw) if existing_raw else []
        all_files = existing + uploaded
        c.execute('UPDATE projects SET media_files = ? WHERE id = ?', (json.dumps(all_files), project_id))
        conn.commit()
        conn.close()
        return {"message": "Media uploaded", "files": all_files, "project_id": project_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Media upload failed: {str(e)}")


@app.get("/projects/{project_id}/media")
async def get_project_media(project_id: int):
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute('SELECT media_files FROM projects WHERE id = ?', (project_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Project not found")
        raw = row['media_files'] if isinstance(row, sqlite3.Row) else row[0]
        files = json.loads(raw) if raw else []
        return {"files": files, "project_id": project_id}
    finally:
        conn.close()


@app.get("/projects/{project_id}/media/{filename}")
async def get_project_media_file(project_id: int, filename: str):
    file_path = UPLOAD_DIR / "media" / str(project_id) / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path=file_path, filename=filename, media_type='application/octet-stream')


@app.post("/projects/{project_id}/request-redo")
async def request_project_redo(project_id: int, data: ProjectAction):
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute('SELECT status, revision_count FROM projects WHERE id = ?', (project_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Project not found")
        current_status = row['status'] if isinstance(row, sqlite3.Row) else row[0]
        rev_count = (row['revision_count'] if isinstance(row, sqlite3.Row) else row[1]) or 0
        if current_status not in ('completed', 'in_progress'):
            raise HTTPException(status_code=400, detail="Project must be completed to request redo")
        c.execute(
            'UPDATE projects SET status = ?, revision_request = ?, revision_count = ?, completion_files = NULL, completion_notes = NULL WHERE id = ?',
            ('in_progress', data.note or data.reason, rev_count + 1, project_id)
        )
        conn.commit()
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        return row_to_dict(c.fetchone())
    finally:
        conn.close()


@app.post("/projects/{project_id}/cancel")
async def cancel_project(project_id: int, data: ProjectAction):
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute('SELECT status FROM projects WHERE id = ?', (project_id,))
        row = c.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Project not found")
        status = row['status'] if isinstance(row, sqlite3.Row) else row[0]
        if status == 'paid':
            raise HTTPException(status_code=400, detail="Cannot cancel a paid project")
        c.execute(
            'UPDATE projects SET status = ?, revision_request = ? WHERE id = ?',
            ('cancelled', data.reason or data.note, project_id)
        )
        conn.commit()
        c.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        return row_to_dict(c.fetchone())
    finally:
        conn.close()


# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Blockchain Freelancing Platform API",
        "version": "1.0.0",
        "docs": "/docs"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app", 
        host="0.0.0.0", 
        port=8000, 
        reload=True,
        log_level="info"
    )