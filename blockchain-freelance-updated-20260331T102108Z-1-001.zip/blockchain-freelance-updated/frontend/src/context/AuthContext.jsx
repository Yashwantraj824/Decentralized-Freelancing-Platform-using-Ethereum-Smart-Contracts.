// src/context/AuthContext.jsx
import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('freelance_user');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        if (userData.id !== undefined && userData.id !== null) {
          userData.id = parseInt(userData.id, 10);
        }
        // load private key from separate key store if exists
        if (!userData.private_key && localStorage.getItem('freelance_private_key')) {
          userData.private_key = localStorage.getItem('freelance_private_key');
        }
        setUser(userData);
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('freelance_user');
        localStorage.removeItem('freelance_private_key');
      }
    }
    setLoading(false);
  }, []);

  const login = (userData) => {
    const userWithIntId = { ...userData };
    if (userWithIntId.id !== undefined && userWithIntId.id !== null) {
      userWithIntId.id = parseInt(userWithIntId.id, 10);
    }
    setUser(userWithIntId);
    localStorage.setItem('freelance_user', JSON.stringify(userWithIntId));
    if (userWithIntId.private_key) {
      localStorage.setItem('freelance_private_key', userWithIntId.private_key);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('freelance_user');
    localStorage.removeItem('freelance_private_key');
  };

  const updateUser = (updates) => {
    const updatedUser = {
      ...user,
      ...updates,
    };
    if (updatedUser.id !== undefined && updatedUser.id !== null) {
      updatedUser.id = parseInt(updatedUser.id, 10);
    }
    setUser(updatedUser);
    localStorage.setItem('freelance_user', JSON.stringify(updatedUser));
    if (updates.private_key) localStorage.setItem('freelance_private_key', updates.private_key);
  };

  const value = {
    user,
    login,
    logout,
    updateUser,
    loading,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
