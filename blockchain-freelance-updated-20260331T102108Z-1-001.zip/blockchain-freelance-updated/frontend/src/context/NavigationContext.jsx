import React, { createContext, useContext } from 'react';

const NavigationContext = createContext(null);

export function NavigationProvider({ children, setCurrentPage }) {
  return (
    <NavigationContext.Provider value={{ setCurrentPage }}>
      {children}
    </NavigationContext.Provider>
  );
}

export function useNavigation() {
  return useContext(NavigationContext);
}
