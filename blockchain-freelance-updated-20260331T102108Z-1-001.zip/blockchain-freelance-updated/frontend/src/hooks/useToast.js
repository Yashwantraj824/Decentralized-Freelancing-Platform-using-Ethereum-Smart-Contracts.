import { useState, useCallback } from 'react';

export function useToast() {
  const [notifications, setNotifications] = useState([]);

  const showToast = useCallback((message, type = 'default', duration = 5000) => {
    const id = Math.random().toString(36).substr(2, 9);
    const notification = { 
      id, 
      message, 
      type,
      timestamp: Date.now()
    };
    
    setNotifications(prev => [...prev, notification]);
    
    // Auto-remove notification after duration
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, duration);

    // Also log to console for development
    const logMethod = type === 'error' ? console.error : 
                     type === 'warning' ? console.warn : 
                     console.log;
    logMethod(`Toast ${type.toUpperCase()}: ${message}`);
  }, []);

  const removeToast = useCallback((id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Create the toast object with methods
  const toast = useCallback((message, type, duration) => {
    showToast(message, type, duration);
  }, [showToast]);

  // Add methods to the toast function
  toast.success = useCallback((msg, duration) => showToast(msg, 'success', duration), [showToast]);
  toast.error = useCallback((msg, duration) => showToast(msg, 'error', duration), [showToast]);
  toast.warning = useCallback((msg, duration) => showToast(msg, 'warning', duration), [showToast]);
  toast.info = useCallback((msg, duration) => showToast(msg, 'info', duration), [showToast]);

  return {
    notifications,
    toast,
    success: toast.success,
    error: toast.error,
    warning: toast.warning,
    info: toast.info,
    removeToast,
    clearAll
  };
}