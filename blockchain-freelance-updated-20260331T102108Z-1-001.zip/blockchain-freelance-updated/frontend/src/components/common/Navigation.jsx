import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Code, LogOut, Briefcase, Plus, FileText, Search, Wallet, User, ChevronDown, Bell, MessageSquare, Menu, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Navigation({ currentPage, setCurrentPage }) {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  if (!user) return null;

  const employerPages = [
    { key: 'dashboard', label: 'Dashboard', icon: Briefcase },
    { key: 'post-project', label: 'Post Requirement', icon: Plus },
    { key: 'my-projects', label: 'My Posted Projects', icon: FileText },
    { key: 'find-freelancers', label: 'Find Freelancers', icon: Search },
    { key: 'wallet', label: 'Wallet', icon: Wallet }
  ];

  const freelancerPages = [
    { key: 'dashboard', label: 'Dashboard', icon: Briefcase },
    { key: 'profile', label: 'My Profile', icon: User },
    { key: 'available-projects', label: 'Browse Projects', icon: Search },
    { key: 'my-projects', label: 'My Work', icon: FileText },
    { key: 'wallet', label: 'Wallet', icon: Wallet }
  ];

  const pages = user.user_type === 'employer' ? employerPages : freelancerPages;

  const handleLogout = () => {
    logout();
    setCurrentPage('home');
  };

  return (
    <nav className="">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar */}
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg">
              <Code className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mr-20">
              FreelanceX
            </span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <div className="flex space-x-1">
              {pages.map(({ key, label, icon: Icon }) => (
                <Button
                  key={key}
                  variant={currentPage === key ? "default" : "ghost"}
                  onClick={() => setCurrentPage(key)}
                  className={`flex items-center space-x-2 rounded-md px-3 py-2 text-sm font-medium transition-all duration-200 ${
                    currentPage === key 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md' 
                      : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{label}</span>
                </Button>
              ))}
            </div>
            
            <div className="flex items-center space-x-4 pl-4 border-l border-gray-200">
              
              
              <div className="flex items-center space-x-2">
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-8 h-8 flex items-center justify-center text-white text-sm font-bold">
                  {user.username.charAt(0).toUpperCase()}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium text-gray-900">{user.username}</div>
                  <div className="text-xs text-gray-500">
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                      {user.user_type === 'employer' ? 'Client' : 'Freelancer'}
                    </Badge>
                  </div>
                </div>
                
              </div>
              
              <Button 
                variant="outline" 
                onClick={handleLogout}
                className="border-gray-300 text-gray-700 hover:bg-gray-50 hover:text-red-600"
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-600"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="grid grid-cols-1 gap-1">
              {pages.map(({ key, label, icon: Icon }) => (
                <Button
                  key={key}
                  variant={currentPage === key ? "default" : "ghost"}
                  onClick={() => {
                    setCurrentPage(key);
                    setMobileMenuOpen(false);
                  }}
                  className={`justify-start px-4 py-3 text-base font-medium ${
                    currentPage === key 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {label}
                </Button>
              ))}
              
              <div className="pt-4 mt-4 border-t border-gray-200">
                <div className="flex items-center px-4 py-2">
                  <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-10 h-10 flex items-center justify-center text-white text-sm font-bold mr-3">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{user.username}</div>
                    <Badge className="bg-blue-100 text-blue-800 mt-1">
                      {user.user_type === 'employer' ? 'Client' : 'Freelancer'}
                    </Badge>
                  </div>
                </div>
                
                <Button 
                  variant="ghost"
                  onClick={handleLogout}
                  className="justify-start px-4 py-3 text-base text-red-600 hover:bg-red-50 w-full mt-2"
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}