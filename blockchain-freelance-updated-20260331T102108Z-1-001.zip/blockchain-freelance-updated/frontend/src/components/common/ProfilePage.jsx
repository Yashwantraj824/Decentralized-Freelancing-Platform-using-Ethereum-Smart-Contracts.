import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { User, Edit, Save, X, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import api from '../../services/api';

export default function ProfilePage() {
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    skills: '',
    experience: 0,
    hourlyRate: 0,
    bio: ''
  });

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const profileData = await api.getFreelancerProfile(user.id);
      setProfile(profileData);
      if (profileData) {
        setFormData({
          skills: profileData.skills || '',
          experience: profileData.experience || 0,
          hourlyRate: profileData.hourly_rate || 0,
          bio: profileData.bio || ''
        });
      }
    } catch (error) {
      // Profile might not exist yet for new users
      setProfile(null);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  const handleSave = async () => {
    if (!formData.skills.trim()) {
      toast.error('Skills are required');
      return;
    }

    if (formData.hourlyRate <= 0) {
      toast.error('Please enter a valid hourly rate');
      return;
    }

    setSaving(true);
    try {
      const profileData = {
        user_id: user.id,
        skills: formData.skills.trim(),
        experience: formData.experience,
        hourly_rate: formData.hourlyRate,
        bio: formData.bio.trim()
      };

      if (profile) {
        // Update existing profile
        await api.updateFreelancerProfile(user.id, profileData);
        toast.success('Profile updated successfully!');
      } else {
        // Create new profile
        await api.createFreelancerProfile(profileData);
        toast.success('Profile created successfully!');
      }

      await loadProfile();
      setIsEditing(false);
    } catch (error) {
      toast.error(error.message || 'Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        skills: profile.skills || '',
        experience: profile.experience || 0,
        hourlyRate: profile.hourly_rate || 0,
        bio: profile.bio || ''
      });
    }
    setIsEditing(false);
  };

  if (user.user_type !== 'freelancer') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Profile management is only available for freelancer accounts.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (loading) {
    return <div className="text-center py-8">Loading profile...</div>;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2 mt-5">My Profile</h1>
        <p className="text-gray-600">Manage your freelancer profile and showcase your skills</p>
      </div>

      {/* Profile Status */}
      {!profile && (
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Complete your profile to start receiving project recommendations and improve your visibility to employers.
          </AlertDescription>
        </Alert>
      )}

      {/* User Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Account Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium text-gray-700">Username:</span>
              <p className="text-gray-600">{user.username}</p>
            </div>
            <div>
              <span className="font-medium text-gray-700">Email:</span>
              <p className="text-gray-600">{user.email}</p>
            </div>
            <div>
              <span className="font-medium text-gray-700">Account Type:</span>
              <Badge variant="outline" className="capitalize">
                {user.user_type}
              </Badge>
            </div>
            <div>
              <span className="font-medium text-gray-700">Wallet:</span>
              <p className="text-gray-600 font-mono text-xs">
                {user.wallet_address?.substring(0, 10)}...
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Freelancer Profile */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Freelancer Profile</CardTitle>
              <CardDescription>
                Your professional information visible to potential employers
              </CardDescription>
            </div>
            {!isEditing && (
              <Button onClick={() => setIsEditing(true)} variant="outline">
                <Edit className="h-4 w-4 mr-2" />
                {profile ? 'Edit' : 'Create'} Profile
              </Button>
            )}
          </div>
        </CardHeader>
        
        <CardContent>
          {isEditing ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="skills">Skills (comma-separated) *</Label>
                <Input
                  id="skills"
                  name="skills"
                  value={formData.skills}
                  onChange={handleInputChange}
                  placeholder="JavaScript, React, Node.js, Smart Contracts"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="experience">Years of Experience</Label>
                  <Input
                    id="experience"
                    name="experience"
                    type="number"
                    min="0"
                    value={formData.experience}
                    onChange={handleInputChange}
                    placeholder="0"
                  />
                </div>
                <div>
                  <Label htmlFor="hourlyRate">Hourly Rate (₹) *</Label>
                  <Input
                    id="hourlyRate"
                    name="hourlyRate"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.hourlyRate}
                    onChange={handleInputChange}
                    placeholder="50.00"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  name="bio"
                  value={formData.bio}
                  onChange={handleInputChange}
                  placeholder="Tell potential employers about your experience, specialties, and what makes you unique..."
                  rows={4}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />
                  {saving ? 'Saving...' : 'Save Profile'}
                </Button>
                <Button onClick={handleCancel} variant="outline" disabled={saving}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : profile ? (
            <div className="space-y-4">
              <div>
                <span className="font-medium text-gray-700">Skills:</span>
                <div className="mt-2 flex flex-wrap gap-2">
                  {profile.skills.split(',').map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill.trim()}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <span className="font-medium text-gray-700">Experience:</span>
                  <p className="text-gray-600">{profile.experience} years</p>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Hourly Rate:</span>
                  <p className="text-gray-600">₹{profile.hourly_rate}/hour</p>
                </div>
              </div>

              {profile.bio && (
                <div>
                  <span className="font-medium text-gray-700">Bio:</span>
                  <p className="text-gray-600 mt-2">{profile.bio}</p>
                </div>
              )}

              <div className="pt-4 border-t">
                <div className="flex items-center space-x-2 text-green-600">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">Profile Complete</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Your profile is visible to employers and eligible for project matching
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <User className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No profile created yet.</p>
              <p className="text-sm">Click "Create Profile" to get started.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Profile Tips */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h3 className="font-medium text-blue-900 mb-2">Profile Tips</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• List specific skills that match project requirements</li>
            <li>• Set a competitive hourly rate based on your experience</li>
            <li>• Write a compelling bio that highlights your expertise</li>
            <li>• Keep your profile updated with new skills and experience</li>
            <li>• A complete profile increases your chances of being hired</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}