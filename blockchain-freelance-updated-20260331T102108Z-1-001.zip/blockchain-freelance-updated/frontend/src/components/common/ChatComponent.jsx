import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Send, Paperclip, X, Download, FileText, AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import api from '../../services/api';

export default function ChatComponent({ projectId, projectTitle }) {
  const { user } = useAuth();
  const { toast } = useToast();

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachedFile, setAttachedFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [ws, setWs] = useState(null);
  const [connected, setConnected] = useState(false);

  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Load message history on mount
  useEffect(() => {
    loadMessages();
  }, [projectId, user]);

  // Connect to WebSocket
  useEffect(() => {
    if (!user || !projectId) return;

    connectWebSocket();

    return () => {
      if (ws) {
        ws.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [projectId, user]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const connectWebSocket = () => {
    try {
      const wsUrl = api.getWebSocketUrl(projectId, user.id);
      console.log('Connecting to WebSocket:', wsUrl);

      const websocket = new WebSocket(wsUrl);

      websocket.onopen = () => {
        console.log('WebSocket connected');
        setConnected(true);
        setWs(websocket);
      };

      websocket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('Received message:', message);

          // Add new message to the list
          setMessages(prev => [...prev, message]);

          // Show notification if message is from another user
          if (message.sender_id !== user.id) {
            toast.info(`New message from ${message.sender_name}`);
          }
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      };

      websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnected(false);
      };

      websocket.onclose = () => {
        console.log('WebSocket disconnected');
        setConnected(false);
        setWs(null);

        // Attempt to reconnect after 3 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log('Attempting to reconnect...');
          connectWebSocket();
        }, 3000);
      };

    } catch (error) {
      console.error('Error connecting to WebSocket:', error);
      setConnected(false);
    }
  };

  const loadMessages = async () => {
    try {
      setLoading(true);
      const data = await api.getProjectMessages(projectId, user.id);
      setMessages(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to load messages:', error);
      toast.error('Failed to load message history');
      setMessages([]);
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast.error('File size must be less than 10MB');
        return;
      }
      setAttachedFile(file);
    }
  };

  const removeAttachedFile = () => {
    setAttachedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();

    if (!newMessage.trim() && !attachedFile) {
      return;
    }

    if (!connected) {
      toast.error('Not connected to chat. Please wait...');
      return;
    }

    setSending(true);

    try {
      let fileUrl = null;
      let fileName = null;

      // Upload file if attached
      if (attachedFile) {
        const uploadResult = await api.uploadMessageFile(projectId, attachedFile);
        fileUrl = uploadResult.file_url;
        fileName = uploadResult.file_name;
      }

      // Prepare message data
      const messageData = {
        message_text: newMessage.trim() || null,
        file_url: fileUrl,
        file_name: fileName
      };

      // Send via WebSocket
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(messageData));

        // Add message to local state immediately (optimistic update)
        const tempMessage = {
          id: Date.now(), // temporary ID
          project_id: projectId,
          sender_id: user.id,
          sender_name: user.username || 'You',
          message_text: messageData.message_text,
          file_url: messageData.file_url,
          file_name: messageData.file_name,
          is_read: true,
          created_at: new Date().toISOString()
        };
        setMessages(prev => [...prev, tempMessage]);

        // Clear input
        setNewMessage('');
        removeAttachedFile();
      } else {
        throw new Error('WebSocket not connected');
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="ml-2 text-gray-600">Loading chat...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Project Chat: {projectTitle}</CardTitle>
          <div className="flex items-center space-x-2">
            {connected ? (
              <div className="flex items-center text-green-600 text-sm">
                <div className="w-2 h-2 bg-green-600 rounded-full mr-2 animate-pulse"></div>
                Connected
              </div>
            ) : (
              <div className="flex items-center text-red-600 text-sm">
                <div className="w-2 h-2 bg-red-600 rounded-full mr-2"></div>
                Disconnected
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      {/* Messages Area */}
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 py-12">
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map((message, index) => {
            const isOwnMessage = message.sender_id === user.id;

            return (
              <div
                key={message.id || index}
                className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[70%] ${isOwnMessage ? 'items-end' : 'items-start'} flex flex-col`}>
                  {!isOwnMessage && (
                    <span className="text-xs text-gray-600 mb-1 px-2">
                      {message.sender_name}
                    </span>
                  )}

                  <div
                    className={`rounded-lg px-4 py-2 ${
                      isOwnMessage
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-900'
                    }`}
                  >
                    {message.message_text && (
                      <p className="whitespace-pre-wrap break-words">{message.message_text}</p>
                    )}

                    {message.file_url && (
                      <a
                        href={api.getMessageFileUrl(message.file_url)}
                        download={message.file_name}
                        className={`flex items-center mt-2 space-x-2 ${
                          isOwnMessage ? 'text-blue-100 hover:text-white' : 'text-blue-600 hover:text-blue-800'
                        }`}
                      >
                        <FileText className="h-4 w-4" />
                        <span className="text-sm underline">{message.file_name}</span>
                        <Download className="h-3 w-3" />
                      </a>
                    )}
                  </div>

                  <span className="text-xs text-gray-500 mt-1 px-2">
                    {formatTimestamp(message.created_at)}
                  </span>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </CardContent>

      {/* Input Area */}
      <div className="border-t p-4">
        {!connected && (
          <Alert variant="warning" className="mb-3">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Reconnecting to chat...
            </AlertDescription>
          </Alert>
        )}

        {attachedFile && (
          <div className="mb-2 flex items-center justify-between bg-blue-50 border border-blue-200 rounded p-2">
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-gray-700">{attachedFile.name}</span>
              <span className="text-xs text-gray-500">
                ({(attachedFile.size / 1024).toFixed(2)} KB)
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={removeAttachedFile}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}

        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileSelect}
            className="hidden"
            accept="image/*,.pdf,.doc,.docx,.txt"
          />

          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            disabled={sending || !connected}
          >
            <Paperclip className="h-4 w-4" />
          </Button>

          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            disabled={sending || !connected}
            className="flex-1"
          />

          <Button
            type="submit"
            disabled={(!newMessage.trim() && !attachedFile) || sending || !connected}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {sending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </div>
    </Card>
  );
}
