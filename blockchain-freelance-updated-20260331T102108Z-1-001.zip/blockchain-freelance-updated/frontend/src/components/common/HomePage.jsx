import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Code, Briefcase, Shield, Zap, Users, Globe, ArrowRight, Star, TrendingUp, Award } from 'lucide-react';

export default function HomePage({ setCurrentPage }) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="absolute top-0 right-0 -mr-40 mt-10 opacity-10">
          <svg width="500" height="500" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M250 0C250 0 322.5 87.5 322.5 250C322.5 412.5 250 500 250 500C250 500 177.5 412.5 177.5 250C177.5 87.5 250 0 250 0Z" fill="white"/>
            <path d="M250 0C250 0 322.5 87.5 322.5 250C322.5 412.5 250 500 250 500" stroke="white" strokeWidth="2"/>
            <path d="M250 0C250 0 177.5 87.5 177.5 250C177.5 412.5 250 500 250 500" stroke="white" strokeWidth="2"/>
            <circle cx="250" cy="250" r="125" stroke="white" strokeWidth="2"/>
          </svg>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500 rounded-full opacity-75 animate-ping"></div>
                <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 p-4 rounded-full shadow-2xl">
                  <Code className="h-12 w-12 text-white" />
                </div>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              The Future of <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Freelancing</span> is Here
            </h1>
            
            <p className="text-xl md:text-2xl text-blue-100 mb-10 max-w-3xl mx-auto leading-relaxed">
              Connect with top talent through our secure blockchain platform. 
              Smart contracts, instant payments, and zero middlemen.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => setCurrentPage('register')} 
                size="lg" 
                className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                Get Started Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                onClick={() => setCurrentPage('login')} 
                variant="outline" 
                size="lg" 
                className="border-white text-blue-900 hover:bg-white hover:text-blue-900 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300"
              >
                Sign In
              </Button>
            </div>
            
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">50K+</div>
                <div className="text-blue-200">Freelancers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">15K+</div>
                <div className="text-blue-200">Employers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">₹25M+</div>
                <div className="text-blue-200">Earned</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">98%</div>
                <div className="text-blue-200">Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Decorative wave */}
        <div className="absolute bottom-0 left-0 w-full">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-16 text-white">
            <path d="M0 60L60 52C120 44 240 28 360 28C480 28 600 44 720 52C840 60 960 60 1080 52C1200 44 1320 28 1380 20L1440 12V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V60Z" fill="currentColor"/>
          </svg>
        </div>
      </div>

      {/* Video/Image Placeholder Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How FreelanceX Works
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our blockchain technology ensures secure, transparent, and efficient freelancing
            </p>
          </div>
          
          <div className="bg-gray-800 rounded-2xl overflow-hidden shadow-2xl max-w-4xl mx-auto">
  <div className="aspect-video bg-black flex items-center justify-center">
    <video
      src="https://www.pexels.com/download/video/4065924/"

      autoPlay
      loop
      muted
      className="w-full h-full object-cover"
    />
  </div>
</div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose FreelanceX?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Leveraging blockchain technology to revolutionize the freelancing industry
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardHeader className="text-center pb-2">
                <div className="bg-blue-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Secure Escrow</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-gray-600">
                  Smart contracts automatically hold funds in escrow until project completion, 
                  ensuring both parties are protected with blockchain security.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardHeader className="text-center pb-2">
                <div className="bg-purple-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl">Instant Payments</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-gray-600">
                  Payments are released instantly upon project completion through 
                  blockchain transactions - no waiting periods or processing delays.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardHeader className="text-center pb-2">
                <div className="bg-indigo-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-indigo-600" />
                </div>
                <CardTitle className="text-xl">Global Access</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-gray-600">
                  Work with clients and freelancers from around the world with 
                  cryptocurrency payments eliminating currency conversion issues.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Simple, transparent process for employers and freelancers
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-2 mb-12">
            <Card className="border-0 shadow-lg overflow-hidden">
              <CardHeader className="bg-gradient-to-r  from-blue-600 to-blue-700 text-white">
                <CardTitle className="flex items-center my-2">
                  <Briefcase className="h-8 w-6 mr-2" />
                  For Employers
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">1</div>
                  <p className="text-gray-700">Post your project with detailed requirements and budget</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">2</div>
                  <p className="text-gray-700">Review applications or browse freelancer profiles</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">3</div>
                  <p className="text-gray-700">Hire your chosen freelancer - smart contract is deployed automatically</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">4</div>
                  <p className="text-gray-700">Release payment when work is completed to your satisfaction</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
                <CardTitle className="flex items-center my-2">
                  <Users className="h-8 w-6 mr-2" />
                  For Freelancers
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 text-purple-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">1</div>
                  <p className="text-gray-700">Create your profile with skills, experience, and portfolio</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 text-purple-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">2</div>
                  <p className="text-gray-700">Browse available projects and apply to those that match your skills</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 text-purple-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">3</div>
                  <p className="text-gray-700">Work on the project knowing your payment is secured in escrow</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 text-purple-600 rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">4</div>
                  <p className="text-gray-700">Receive instant payment when you complete the work</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="py-16 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Our Users Say
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join thousands of satisfied freelancers and employers
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Sarah Johnson", role: "Web Developer", text: "FreelanceX has revolutionized how I get paid. No more waiting for payments or worrying about clients not paying." },
              { name: "Michael Chen", role: "Startup Founder", text: "The smart contract escrow system gives me peace of mind when hiring freelancers for critical projects." },
              { name: "Emma Rodriguez", role: "Graphic Designer", text: "I've doubled my income since switching to FreelanceX. The global client base is incredible!" }
            ].map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-md bg-white overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic mb-6">"{testimonial.text}"</p>
                  <div className="flex items-center">
                    <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-12 h-12 flex items-center justify-center text-white font-bold">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-500">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Freelancing Experience?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join the blockchain revolution and experience secure, transparent freelancing
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => setCurrentPage('register')} 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Create Account
            </Button>
            <Button 
              onClick={() => setCurrentPage('login')} 
              variant="outline" 
              size="lg" 
              className="border-white text-blue-900 hover:bg-white hover:text-blue-600 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300"
            >
              Sign In
            </Button>
          </div>
          
          <div className="mt-12 flex flex-wrap justify-center gap-6">
            <div className="flex items-center">
              <Award className="h-6 w-6 text-blue-300 mr-2" />
              <span className="text-blue-200">Secure Blockchain Technology</span>
            </div>
            <div className="flex items-center">
              <TrendingUp className="h-6 w-6 text-blue-300 mr-2" />
              <span className="text-blue-200">Zero Transaction Fees</span>
            </div>
            <div className="flex items-center">
              <Shield className="h-6 w-6 text-blue-300 mr-2" />
              <span className="text-blue-200">Smart Contract Protection</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}