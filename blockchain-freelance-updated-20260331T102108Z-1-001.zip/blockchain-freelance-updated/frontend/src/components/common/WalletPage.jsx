import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Copy, Wallet, RefreshCw } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import blockchain from '../../services/blockchain';

export default function WalletPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [balance, setBalance] = useState('0');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (user?.wallet_address) {
      loadBalance();
    }
  }, [user]);

  const loadBalance = async () => {
    try {
      setLoading(true);
      const balanceEth = await blockchain.getBalance(user.wallet_address);
      setBalance(balanceEth);
    } catch (error) {
      toast.error('Failed to load wallet balance');
      console.error('Error loading balance:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshBalance = async () => {
    setRefreshing(true);
    await loadBalance();
    setRefreshing(false);
    toast.success('Balance refreshed');
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const formatAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  if (!user) {
    return <div>Please log in to view your wallet.</div>;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-3xl mt-5 font-bold mb-2">Your Wallet</h1>
        <p className="text-gray-600">Manage your blockchain wallet and view your balance</p>
      </div>

      {/* Balance Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wallet className="h-5 w-5" />
              <CardTitle>Wallet Balance</CardTitle>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshBalance}
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            {loading ? (
              <div className="text-2xl font-bold text-gray-400">Loading...</div>
            ) : (
              <div className="text-4xl font-bold text-green-600">
                ₹{parseFloat(balance).toFixed(4)}
              </div>
            )}
            <p className="text-sm text-gray-500 mt-2">
              Connected to Ganache local network
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Wallet Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Wallet Details</CardTitle>
          <CardDescription>Your wallet information and credentials</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700">Wallet Address</label>
            <div className="flex items-center justify-between mt-1 p-3 bg-gray-50 rounded-lg">
              <code className="text-sm font-mono">{user.wallet_address}</code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(user.wallet_address, 'Address')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700">Private Key</label>
            <div className="flex items-center justify-between mt-1 p-3 bg-gray-50 rounded-lg">
              <code className="text-sm font-mono">
                {formatAddress(user.private_key)}
              </code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(user.private_key, 'Private Key')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-red-600 mt-1">
              ⚠️ Keep your private key secure and never share it with anyone
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700">Account Type</label>
            <div className="mt-1">
              <Badge variant="outline" className="capitalize">
                {user.user_type}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Network Information */}
      <Card>
        <CardHeader>
          <CardTitle>Network Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Network:</span>
              <div className="font-medium">Ganache (Local)</div>
            </div>
            <div>
              <span className="text-gray-600">RPC URL:</span>
              <div className="font-medium">http://127.0.0.1:8545</div>
            </div>
            <div>
              <span className="text-gray-600">Chain ID:</span>
              <div className="font-medium">1337</div>
            </div>
            <div>
              <span className="text-gray-600">Currency:</span>
              <div className="font-medium">INR (₹)</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Tips */}
      <Card>
        <CardHeader>
          <CardTitle>Tips & Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="text-sm space-y-2 text-gray-600">
            <li>• Ensure you have sufficient balance before posting projects or deploying contracts</li>
            <li>• Gas fees are required for all blockchain transactions</li>
            <li>• Smart contracts will hold project funds in escrow until completion</li>
            <li>• Keep your private key secure - it cannot be recovered if lost</li>
            <li>• This is a development environment using Ganache local blockchain</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}