// src/components/auth/RegisterPage.jsx
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Eye, EyeOff, Network , UserPlus, Wallet, Key } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import blockchain from '../../services/blockchain';
import api from '../../services/api';

export default function RegisterPage({ setCurrentPage }) {
  const { login } = useAuth();
  const { toast } = useToast();
  const [userType, setUserType] = useState('employer'); // 'employer' = Client, 'freelancer' = Freelancer
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    walletAddress: '',
    privateKey: '',
    skills: '',
    experience: 0,
    hourlyRate: 0,
    bio: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showPrivateKey, setShowPrivateKey] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
    setError('');
  };

  const validateForm = () => {
    if (!formData.username || !formData.email || !formData.password) {
      return 'Please fill in all required fields';
    }

    if (formData.password !== formData.confirmPassword) {
      return "Passwords don't match!";
    }

    if (formData.password.length < 6) {
      return 'Password must be at least 6 characters long';
    }

    if (!formData.walletAddress || !formData.privateKey) {
      return 'Wallet address and private key are required';
    }

    if (userType === 'freelancer') {
      if (!formData.skills || formData.hourlyRate <= 0) {
        return 'Please fill in your skills and hourly rate';
      }
    }

    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    // Validate wallet credentials
    

    setLoading(true);
    setError('');

    try {
      // Create user (api.createUser returns a user object)
      const createdUser = await api.createUser({
        username: formData.username,
        email: formData.email,
        password: formData.password,
        user_type: userType,
        wallet_address: formData.walletAddress,
        private_key: formData.privateKey
      });

      if (!createdUser || !createdUser.id) {
        throw new Error('Registration failed - no user id returned');
      }

      const userId = createdUser.id;

      // Create freelancer profile if needed
      if (userType === 'freelancer') {
        await api.createFreelancerProfile({
          user_id: userId,
          skills: formData.skills,
          experience: formData.experience,
          hourly_rate: formData.hourlyRate,
          bio: formData.bio
        });
      }

      // Verify & login
      const userData = await api.verifyUser(formData.email, formData.password);
      login(userData);

      toast.success('Registration successful!');
      setCurrentPage('dashboard');

    } catch (error) {
      console.error('Register error', error);
      setError(error.message || 'Registration failed');
      toast.error('Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4 py-8">
      <div className="absolute top-10 left-10 flex items-center space-x-2">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg">
          <Network className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          FreelanceX
        </h1>
      </div>
      
      <Card className="w-full max-w-2xl shadow-xl">
        <div className=" p-1">
          <div className="bg-white rounded-t-lg py-2">
            <CardHeader className="text-center space-y-3">
              <div className="flex justify-center">
                <div className="p-2 bg-blue-100 rounded-full">
                  <UserPlus className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <CardTitle className="text-2xl font-bold text-gray-800">Join FreelanceX</CardTitle>
              <CardDescription className="text-gray-600">
                Create your account to access the blockchain-powered freelance marketplace
              </CardDescription>
            </CardHeader>
          </div>
        </div>
        
        <CardContent className="pt-6">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="userType" className="text-gray-700">I want to join as</Label>
              <Select value={userType} onValueChange={setUserType}>
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="employer" className="flex items-center">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                      Client (Hire Freelancers)
                    </div>
                  </SelectItem>
                  <SelectItem value="freelancer">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                      Freelancer (Find Work)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="username" className="text-gray-700">Username *</Label>
                <Input
                  id="username"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  placeholder="Enter username"
                  required
                  className="py-2 focus:ring-2 focus:ring-blue-500 mt-1"
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-gray-700">Email *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Enter email"
                  required
                  className="py-2 focus:ring-2 focus:ring-blue-500 mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="password" className="text-gray-700">Password *</Label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter password"
                    required
                    className="py-2 pr-10 focus:ring-2 focus:ring-blue-500 mt-1"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center mt-1"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
              <div>
                <Label htmlFor="confirmPassword" className="text-gray-700">Confirm Password *</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    placeholder="Confirm password"
                    required
                    className="py-2 pr-10 focus:ring-2 focus:ring-blue-500 mt-1"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center mt-1"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
              <div className="flex items-center mb-2">
                <Wallet className="h-5 w-5 text-blue-600 mr-2" />
                <h3 className="font-medium text-blue-800">Blockchain Wallet Details</h3>
              </div>
              <p className="text-sm text-blue-600 mb-3">Connect your Ethereum wallet to use smart contracts</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="walletAddress" className="text-gray-700">Wallet Address *</Label>
                  <Input
                    id="walletAddress"
                    name="walletAddress"
                    value={formData.walletAddress}
                    onChange={handleInputChange}
                    placeholder="0x..."
                    required
                    className="py-2 focus:ring-2 focus:ring-blue-500 mt-1 font-mono text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="privateKey" className="text-gray-700">Private Key *</Label>
                  <div className="relative">
                    <Input
                      id="privateKey"
                      name="privateKey"
                      type={showPrivateKey ? "text" : "password"}
                      value={formData.privateKey}
                      onChange={handleInputChange}
                      placeholder="0x..."
                      required
                      className="py-2 pr-10 focus:ring-2 focus:ring-blue-500 mt-1 font-mono text-sm"
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center mt-1"
                      onClick={() => setShowPrivateKey(!showPrivateKey)}
                    >
                      {showPrivateKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              <p className="text-xs text-blue-500 mt-2 flex items-center">
                <Key className="h-3 w-3 mr-1" />
                Your private key is encrypted and stored securely
              </p>
            </div>

            {userType === 'freelancer' && (
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-100">
                <div className="flex items-center mb-2">
                  <div className="bg-purple-100 p-1 rounded mr-2">
                    <UserPlus className="h-4 w-4 text-purple-600" />
                  </div>
                  <h3 className="font-medium text-purple-800">Freelancer Profile</h3>
                </div>
                
                <div className="mt-3">
                  <Label htmlFor="skills" className="text-gray-700">Skills (comma-separated) *</Label>
                  <Input
                    id="skills"
                    name="skills"
                    value={formData.skills}
                    onChange={handleInputChange}
                    placeholder="JavaScript, React, Node.js"
                    required
                    className="py-2 focus:ring-2 focus:ring-purple-500 mt-1"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                  <div>
                    <Label htmlFor="experience" className="text-gray-700">Years of Experience</Label>
                    <Input
                      id="experience"
                      name="experience"
                      type="number"
                      min="0"
                      value={formData.experience}
                      onChange={handleInputChange}
                      placeholder="0"
                      className="py-2 focus:ring-2 focus:ring-purple-500 mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="hourlyRate" className="text-gray-700">Hourly Rate (₹) *</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">₹</span>
                      <Input
                        id="hourlyRate"
                        name="hourlyRate"
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.hourlyRate}
                        onChange={handleInputChange}
                        placeholder="50.00"
                        required
                        className="py-2 pl-7 focus:ring-2 focus:ring-purple-500 mt-1"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-3">
                  <Label htmlFor="bio" className="text-gray-700">Bio</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    placeholder="Tell us about yourself, your experience, and what you can offer to clients..."
                    rows={3}
                    className="focus:ring-2 focus:ring-purple-500 mt-1"
                  />
                </div>
              </div>
            )}

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-2 font-medium text-white transition-all duration-200 transform hover:scale-[1.02] shadow-md" 
              disabled={loading}
            >
              {loading ? (
                <div className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating Account...
                </div>
              ) : (
                <div className="flex items-center">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create Account
                </div>
              )}
            </Button>
            
            <div className="text-center">
              <span className="text-sm text-gray-600">
                Already have an account?{' '}
                <Button 
                  variant="link" 
                  className="p-0 h-auto font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"
                  onClick={() => setCurrentPage('login')}
                >
                  Login here
                </Button>
              </span>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}