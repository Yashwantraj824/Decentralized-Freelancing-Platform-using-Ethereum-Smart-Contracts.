import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Briefcase, Clock, CheckCircle, DollarSign, Users, TrendingUp, Plus, AlertCircle, ArrowRight, Eye, FileText, Zap } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { useNavigation } from '../../context/NavigationContext';
import api from '../../services/api';
import ProjectList from '../projects/ProjectList';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

export default function EmployerDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { setCurrentPage } = useNavigation();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    open: 0,
    active: 0,
    completed: 0,
    totalBudget: 0
  });

  useEffect(() => {
    if (user) {
      loadProjects();
    } else {
      setProjects([]);
      setLoading(false);
    }
  }, [user]);

  const loadProjects = async () => {
    try {
      setLoading(true);
      setError('');
      
      const data = await api.getProjects({ employer_id: user.id });
      
      if (Array.isArray(data)) {
        setProjects(data);
        calculateStats(data);
      } else if (data && Array.isArray(data.projects)) {
        setProjects(data.projects);
        calculateStats(data.projects);
      } else {
        console.warn('Unexpected API response format:', data);
        setProjects([]);
        calculateStats([]);
      }
    } catch (err) {
      console.error('Failed to load employer projects:', err);
      setError('Failed to load projects');
      setProjects([]);
      calculateStats([]);
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (projectsData) => {
    const newStats = {
      total: projectsData.length,
      open: projectsData.filter(p => p.status === 'open').length,
      active: projectsData.filter(p => ['assigned', 'in_progress', 'completed'].includes(p.status)).length,
      completed: projectsData.filter(p => ['paid', 'completed'].includes(p.status)).length,
      totalBudget: projectsData.reduce((sum, p) => sum + (Number(p.budget) || 0), 0)
    };
    setStats(newStats);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600">Please login to view your employer dashboard</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
          <p className="text-sm text-gray-500 mt-2">Securely connecting to blockchain network</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Client Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, {user.username}! Manage your posted projects and track performance.</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-10 h-10 flex items-center justify-center text-white font-bold">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="font-medium text-gray-900">{user.username}</p>
              <p className="text-sm text-gray-500">Client</p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-red-100 p-2 rounded-full mr-3">
                <AlertCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-red-800 font-medium">{error}</p>
                <p className="text-red-600 text-sm">Please try refreshing the page</p>
              </div>
            </div>
            <Button 
              onClick={loadProjects} 
              variant="outline" 
              size="sm"
              className="text-red-700 border-red-200 hover:bg-red-100"
            >
              Retry
            </Button>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Projects</CardTitle>
              <div className="bg-blue-100 p-2 rounded-lg">
                <Briefcase className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="flex items-center mt-1">
                <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">
                  {stats.open} open
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Active Projects</CardTitle>
              <div className="bg-purple-100 p-2 rounded-lg">
                <Clock className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.active}</div>
              <p className="text-xs text-muted-foreground mt-1">
                In progress or assigned
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
              <div className="bg-green-100 p-2 rounded-lg">
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.completed}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Successfully completed
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Budget</CardTitle>
              <div className="bg-amber-100 p-2 rounded-lg">
                <DollarSign className="h-4 w-4 text-amber-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">₹{stats.totalBudget.toFixed(4)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Across all projects
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Projects */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Stats */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                  Project Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{stats.open}</div>
                    <p className="text-sm text-blue-700">Open Projects</p>
                    <p className="text-xs text-blue-500">Waiting for freelancers</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{stats.active}</div>
                    <p className="text-sm text-purple-700">Active Projects</p>
                    <p className="text-xs text-purple-500">In progress</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
                    <p className="text-sm text-green-700">Completed</p>
                    <p className="text-xs text-green-500">Successfully delivered</p>
                  </div>
                  <div className="text-center p-4 bg-amber-50 rounded-lg">
                    <div className="text-2xl font-bold text-amber-600">{stats.totalBudget.toFixed(2)}</div>
                    <p className="text-sm text-amber-700">₹ Spent</p>
                    <p className="text-xs text-amber-500">Total investment</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* All Projects */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>My Posted Projects ({projects.length})</CardTitle>
                    <CardDescription>
                      Manage and track all your posted project requirements
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setCurrentPage('post-project')}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    New Project
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {projects.length > 0 ? (
                  <ProjectList
                    projects={projects}
                    onUpdate={loadProjects}
                    isEmployer={true}
                    userProjects={true}
                  />
                ) : (
                  <div className="text-center py-12">
                    <div className="bg-gray-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <Briefcase className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No projects yet</h3>
                    <p className="text-gray-600 mb-6">Get started by posting your first project</p>
                    <Button 
                      onClick={() => setCurrentPage('post-project')}
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Your First Project
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-blue-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <div 
                    className="p-4 border rounded-lg hover:border-blue-300 hover:bg-blue-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('post-project')}
                  >
                    <div className="flex items-center">
                      <div className="bg-blue-100 p-2 rounded-lg group-hover:bg-blue-200 transition-colors">
                        <Plus className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">Post a Project Requirement</h3>
                        <p className="text-sm text-gray-600">Describe your needs and find the right freelancer</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="p-4 border rounded-lg hover:border-purple-300 hover:bg-purple-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('find-freelancers')}
                  >
                    <div className="flex items-center">
                      <div className="bg-purple-100 p-2 rounded-lg group-hover:bg-purple-200 transition-colors">
                        <Users className="h-5 w-5 text-purple-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">Find Freelancers</h3>
                        <p className="text-sm text-gray-600">Browse talented professionals</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="p-4 border rounded-lg hover:border-green-300 hover:bg-green-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('wallet')}
                  >
                    <div className="flex items-center">
                      <div className="bg-green-100 p-2 rounded-lg group-hover:bg-green-200 transition-colors">
                        <DollarSign className="h-5 w-5 text-green-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">Manage Wallet</h3>
                        <p className="text-sm text-gray-600">Add funds and view transactions</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Project Completion Rate</span>
                      <span className="text-sm text-gray-500">{(stats.completed / stats.total * 100 || 0).toFixed(0)}%</span>
                    </div>
                    <Progress value={(stats.completed / stats.total * 100) || 0} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Average Budget</span>
                      <span className="text-sm text-gray-500">
                        ₹{stats.total > 0 ? (stats.totalBudget / stats.total).toFixed(2) : '0.00'}
                      </span>
                    </div>
                    <Progress value={Math.min((stats.totalBudget / stats.total) * 10 || 0, 100)} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Active Engagement</span>
                      <span className="text-sm text-gray-500">
                        {((stats.active / stats.total) * 100 || 0).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={(stats.active / stats.total * 100) || 0} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-blue-600" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {projects.slice(0, 3).map((project, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`p-2 rounded-full mr-3 mt-1 ${
                        project.status === 'open' ? 'bg-blue-100' :
                        project.status === 'completed' ? 'bg-green-100' :
                        'bg-purple-100'
                      }`}>
                        {project.status === 'open' ? (
                          <FileText className="h-4 w-4 text-blue-600" />
                        ) : project.status === 'completed' ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <Clock className="h-4 w-4 text-purple-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 truncate">{project.title}</p>
                        <p className="text-xs text-gray-500 capitalize">{project.status.replace('_', ' ')}</p>
                      </div>
                      <Badge variant="outline" className="bg-gray-100">
                        ₹{project.budget}
                      </Badge>
                    </div>
                  ))}
                  
                  {projects.length === 0 && (
                    <div className="text-center py-4">
                      <p className="text-sm text-gray-500">No recent activity</p>
                    </div>
                  )}
                  
                  {projects.length > 0 && (
                    <Button variant="ghost" className="w-full text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                      <Eye className="h-4 w-4 mr-2" />
                      View All Activity
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}