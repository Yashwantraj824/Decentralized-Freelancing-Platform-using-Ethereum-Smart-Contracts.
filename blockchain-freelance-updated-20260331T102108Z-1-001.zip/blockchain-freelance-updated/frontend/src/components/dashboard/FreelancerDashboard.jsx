import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Briefcase, Clock, CheckCircle, DollarSign, Star, TrendingUp, Users, Award, Zap, ArrowRight, Eye, User, Search, Wallet } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { useNavigation } from '../../context/NavigationContext';
import api from '../../services/api';
import ProjectList from '../projects/ProjectList';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

export default function FreelancerDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { setCurrentPage } = useNavigation();
  const [myProjects, setMyProjects] = useState([]);
  const [availableProjects, setAvailableProjects] = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user?.id) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user?.id) {
      setError('User not authenticated');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError('');
      
      // Ensure user ID is integer for all API calls
      const userId = parseInt(user.id);
      
      const [mine, available, profileData] = await Promise.all([
        api.getProjects({ freelancer_id: userId }),
        api.getProjects({ status: 'open' }),
        api.getFreelancerProfile(userId).catch((error) => {
          console.log('Profile not found or error:', error);
          return null;
        })
      ]);
      
      setMyProjects(Array.isArray(mine) ? mine : []);
      setAvailableProjects(Array.isArray(available) ? available : []);
      setProfile(profileData);
    } catch (error) {
      console.error('Dashboard loading error:', error);
      setError('Failed to load dashboard data');
      toast.error('Failed to load data');
      setMyProjects([]);
      setAvailableProjects([]);
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    totalProjects: myProjects.length,
    activeProjects: myProjects.filter(p => ['assigned', 'completed'].includes(p.status)).length,
    completedProjects: myProjects.filter(p => p.status === 'paid').length,
    totalEarnings: myProjects
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + (parseFloat(p.budget) || 0), 0),
    availableOpportunities: availableProjects.length
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
          <p className="text-sm text-gray-500 mt-2">Securely connecting to blockchain network</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">Please log in to view your dashboard</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Freelancer Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, {user.username}! Here's your work overview.</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-10 h-10 flex items-center justify-center text-white font-bold">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="font-medium text-gray-900">{user.username}</p>
              <p className="text-sm text-gray-500">Freelancer</p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-red-100 p-2 rounded-full mr-3">
                <span className="text-red-600 text-sm">⚠️</span>
              </div>
              <div>
                <p className="text-red-800 font-medium">{error}</p>
                <p className="text-red-600 text-sm">Please try again</p>
              </div>
            </div>
            <Button 
              onClick={loadData} 
              variant="outline" 
              size="sm"
              className="text-red-700 border-red-200 hover:bg-red-100"
            >
              Retry
            </Button>
          </div>
        )}

        {/* Profile Status Alert */}
        {!profile && !loading && (
          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-yellow-100 p-2 rounded-full mr-3">
                <span className="text-yellow-600">💼</span>
              </div>
              <div>
                <p className="text-yellow-800 font-medium">Complete your freelancer profile</p>
                <p className="text-yellow-600 text-sm">Increase your chances of getting hired by 70%</p>
              </div>
            </div>
            <Button 
              onClick={() => setCurrentPage('profile')}
              className="bg-yellow-500 hover:bg-yellow-600 text-white"
            >
              Create Profile
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Projects</CardTitle>
              <div className="bg-blue-100 p-2 rounded-lg">
                <Briefcase className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.totalProjects}</div>
              <p className="text-xs text-muted-foreground mt-1">
                All projects worked on
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Active Projects</CardTitle>
              <div className="bg-purple-100 p-2 rounded-lg">
                <Clock className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.activeProjects}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Currently in progress
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
              <div className="bg-green-100 p-2 rounded-lg">
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.completedProjects}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Successfully finished
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Earnings</CardTitle>
              <div className="bg-amber-100 p-2 rounded-lg">
                <DollarSign className="h-4 w-4 text-amber-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">₹{stats.totalEarnings.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                From completed projects
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Available</CardTitle>
              <div className="bg-indigo-100 p-2 rounded-lg">
                <TrendingUp className="h-4 w-4 text-indigo-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.availableOpportunities}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Open opportunities
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Profile Summary */}
            {profile && (
              <Card className="border-0 shadow-md overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                  <CardTitle className="flex items-center">
                    <User className="h-5 w-5 mr-2 text-blue-600" />
                    Your Profile
                  </CardTitle>
                  <CardDescription>
                    Your profile is {profile.skills ? '85%' : '30%'} complete
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                    <div>
                      <span className="font-medium text-gray-700">Skills:</span>
                      <p className="text-gray-600 mt-1">{profile.skills || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Experience:</span>
                      <p className="text-gray-600 mt-1">{profile.experience || 0} years</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Hourly Rate:</span>
                      <p className="text-gray-600 mt-1">₹{profile.hourly_rate || 0}/hour</p>
                    </div>
                  </div>
                  {profile.bio && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <span className="font-medium text-gray-700">Bio:</span>
                      <p className="text-gray-600 text-sm mt-1">{profile.bio}</p>
                    </div>
                  )}
                  <Button variant="outline" className="w-full mt-4" onClick={() => setCurrentPage('profile')}>
                    <Eye className="h-4 w-4 mr-2" />
                    View Full Profile
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Projects Tabs */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="border-b">
                <CardTitle>Your Work</CardTitle>
                <CardDescription>
                  Browse open projects or manage your current work
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Tabs defaultValue="available" className="w-full">
                  <TabsList className="w-full grid grid-cols-2 rounded-none border-b">
                    <TabsTrigger value="available" className="py-4 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
                      <Search className="h-4 w-4 mr-2" />
                      Browse Projects ({stats.availableOpportunities})
                    </TabsTrigger>
                    <TabsTrigger value="my-projects" className="py-4 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
                      <Briefcase className="h-4 w-4 mr-2" />
                      My Work ({stats.totalProjects})
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="available" className="p-6">
                    <div className="space-y-4">
                      {availableProjects.length > 0 ? (
                        <ProjectList 
                          projects={availableProjects} 
                          showApply={true}
                          onUpdate={loadData}
                        />
                      ) : (
                        <div className="text-center py-8">
                          <div className="bg-gray-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <Search className="h-8 w-8 text-gray-400" />
                          </div>
                          <p className="text-gray-600">No available projects at the moment</p>
                          <p className="text-sm text-gray-500 mt-2">Check back later for new opportunities</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="my-projects" className="p-6">
                    <div className="space-y-4">
                      {myProjects.length > 0 ? (
                        <ProjectList 
                          projects={myProjects} 
                          onUpdate={loadData}
                        />
                      ) : (
                        <div className="text-center py-8">
                          <div className="bg-gray-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <Briefcase className="h-8 w-8 text-gray-400" />
                          </div>
                          <p className="text-gray-600">No work yet</p>
                          <p className="text-sm text-gray-500 mt-2">Apply to open project requirements to get started</p>
                          <Button className="mt-4" onClick={() => setCurrentPage('available-projects')}>
                            Browse Open Projects
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-blue-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <div 
                    className="p-4 border rounded-lg hover:border-blue-300 hover:bg-blue-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('profile')}
                  >
                    <div className="flex items-center">
                      <div className="bg-blue-100 p-2 rounded-lg group-hover:bg-blue-200 transition-colors">
                        <User className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">Update Profile</h3>
                        <p className="text-sm text-gray-600">Keep your skills and rates current</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="p-4 border rounded-lg hover:border-purple-300 hover:bg-purple-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('available-projects')}
                  >
                    <div className="flex items-center">
                      <div className="bg-purple-100 p-2 rounded-lg group-hover:bg-purple-200 transition-colors">
                        <Search className="h-5 w-5 text-purple-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">Browse Projects</h3>
                        <p className="text-sm text-gray-600">Find new opportunities</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="p-4 border rounded-lg hover:border-green-300 hover:bg-green-50 cursor-pointer transition-all duration-200 group"
                    onClick={() => setCurrentPage('wallet')}
                  >
                    <div className="flex items-center">
                      <div className="bg-green-100 p-2 rounded-lg group-hover:bg-green-200 transition-colors">
                        <Wallet className="h-5 w-5 text-green-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">View Wallet</h3>
                        <p className="text-sm text-gray-600">Check your balance</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Performance Stats */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                  Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Profile Completion</span>
                      <span className="text-sm text-gray-500">{profile ? '85%' : '30%'}</span>
                    </div>
                    <Progress value={profile ? 85 : 30} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Response Rate</span>
                      <span className="text-sm text-gray-500">92%</span>
                    </div>
                    <Progress value={92} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Client Satisfaction</span>
                      <span className="text-sm text-gray-500">4.8/5</span>
                    </div>
                    <Progress value={96} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-0 shadow-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-blue-600" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-green-100 p-2 rounded-full mr-3 mt-1">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Project completed</p>
                      <p className="text-xs text-gray-500">Web Development • 2 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-2 rounded-full mr-3 mt-1">
                      <Briefcase className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">New project assigned</p>
                      <p className="text-xs text-gray-500">UI/UX Design • 1 day ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-amber-100 p-2 rounded-full mr-3 mt-1">
                      <DollarSign className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Payment received</p>
                      <p className="text-xs text-gray-500">₹2.5 • 2 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}