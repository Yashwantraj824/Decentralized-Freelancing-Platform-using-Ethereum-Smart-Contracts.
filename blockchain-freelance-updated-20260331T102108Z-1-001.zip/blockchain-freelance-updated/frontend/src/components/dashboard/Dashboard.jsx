import React from 'react';
import { useAuth } from '../../context/AuthContext';
import EmployerDashboard from './EmployerDashboard';
import FreelancerDashboard from './FreelancerDashboard';

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return <div>Please log in to access your dashboard.</div>;
  }

  return user.user_type === 'employer' ? <EmployerDashboard /> : <FreelancerDashboard />;
}