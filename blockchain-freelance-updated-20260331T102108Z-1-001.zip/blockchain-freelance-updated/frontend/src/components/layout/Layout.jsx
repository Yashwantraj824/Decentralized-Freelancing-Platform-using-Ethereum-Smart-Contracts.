import React from 'react';
import Navigation from '../common/Navigation';
import { useAuth } from '../../context/AuthContext';

export default function Layout({ children, currentPage, setCurrentPage }) {
  const { user } = useAuth();

  return (
    <div className="min-h-screen ">
      {/* top nav always inside a constrained container so spacing is consistent */}
      <header className="sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} user={user} />
        </div>
      </header>

      {/* main content constrained to same max width so cards center */}
      <main className="">
        {children}
      </main>
    </div>
  );
}
