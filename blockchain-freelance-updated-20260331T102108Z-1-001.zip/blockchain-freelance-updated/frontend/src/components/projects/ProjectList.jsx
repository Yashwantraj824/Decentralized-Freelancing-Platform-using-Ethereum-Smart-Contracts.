// src/components/projects/ProjectList.jsx
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  DollarSign, Calendar, User, Copy, Play, CheckCircle, Loader2, Upload,
  FileText, Download, X, Eye, MessageSquare, ScrollText, Shield,
  RotateCcw, Ban, AlertTriangle, ImageIcon, SplitSquareHorizontal,
  Image, PlusCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import api from '../../services/api';
import blockchain from '../../services/blockchain';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import ChatComponent from '../common/ChatComponent';

export default function ProjectList({
  projects: initialProjects,
  onUpdate,
  userProjects = false,
  availableProjects = false,
  isEmployer = false,
  showApply = false
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [projects, setProjects] = useState(initialProjects || []);
  const [loading, setLoading] = useState(!initialProjects);
  const [actionLoading, setActionLoading] = useState({});
  const [showFileUploadModal, setShowFileUploadModal] = useState(false);
  const [showFileViewModal, setShowFileViewModal] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [uploadFiles, setUploadFiles] = useState([]);
  const [uploadNotes, setUploadNotes] = useState('');
  const [completionFiles, setCompletionFiles] = useState(null);
  const [unreadCounts, setUnreadCounts] = useState({});
  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [agreementProject, setAgreementProject] = useState(null);
  const [agreementChecked, setAgreementChecked] = useState(false);

  // Cancel & Redo state
  const [showRedoModal, setShowRedoModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [redoNote, setRedoNote] = useState('');
  const [cancelReason, setCancelReason] = useState('');

  // Media preview state
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [projectMedia, setProjectMedia] = useState([]);

  useEffect(() => {
    if (!initialProjects) {
      loadProjects();
    } else {
      setProjects(initialProjects);
    }
  }, [initialProjects]);

  useEffect(() => {
    if (user?.id) {
      loadUnreadCounts();
      const interval = setInterval(loadUnreadCounts, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadProjects = async () => {
    try {
      setLoading(true);
      let filters = {};

      if (userProjects) {
        if (user.user_type === 'employer') {
          filters.employer_id = user.id;
        } else {
          filters.freelancer_id = user.id;
        }
      } else if (availableProjects) {
        filters.status = 'open';
      }

      const data = await api.getProjects(filters);
      setProjects(Array.isArray(data) ? data : []);
    } catch (error) {
      toast.error('Failed to load projects');
      setProjects([]);
    } finally {
      setLoading(false);
    }
  };

  const loadUnreadCounts = async () => {
    try {
      const counts = await api.getUnreadMessageCounts(user.id);
      setUnreadCounts(counts || {});
    } catch (error) {
      console.error('Failed to load unread counts:', error);
    }
  };

  const openChat = (project) => {
    setSelectedProject(project);
    setShowChatModal(true);
    setUnreadCounts(prev => {
      const newCounts = { ...prev };
      delete newCounts[project.id];
      return newCounts;
    });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      open: { label: 'Open', color: 'bg-blue-100 text-blue-800' },
      pending: { label: 'Agreement Signed', color: 'bg-indigo-100 text-indigo-800' },
      assigned: { label: 'Assigned', color: 'bg-yellow-100 text-yellow-800' },
      in_progress: { label: 'In Progress', color: 'bg-orange-100 text-orange-800' },
      completed: { label: 'Completed', color: 'bg-green-100 text-green-800' },
      paid: { label: 'Paid', color: 'bg-emerald-100 text-emerald-800' },
      cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-800' },
    };
    const config = statusConfig[status] || statusConfig.open;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  const openAgreementModal = (project) => {
    setAgreementProject(project);
    setAgreementChecked(false);
    setShowAgreementModal(true);
  };

  // Apply: sets status to 'pending' (agreement signed, waiting for Start Project)
  const handleApply = async (projectId) => {
    setActionLoading(prev => ({ ...prev, [`apply_${projectId}`]: true }));
    setShowAgreementModal(false);

    try {
      await api.updateProject(projectId, {
        freelancer_id: user.id,
        status: 'pending'
      });

      toast.success('Agreement accepted! The project has been reserved for you. Click "Start Project" when you\'re ready.');
      if (onUpdate) onUpdate();
      else loadProjects();
    } catch (error) {
      toast.error('Failed to accept agreement');
    } finally {
      setActionLoading(prev => ({ ...prev, [`apply_${projectId}`]: false }));
    }
  };

  const ensureContractOnProject = async (project) => {
    if (project.contract_address) return project.contract_address;
    try {
      const res = await api.ensureProjectContract(project.id);
      const addr = res?.contract_address || res?.contractAddress || res?.address;
      if (!addr) throw new Error('No contract address returned from server');
      setProjects(prev => prev.map(p => p.id === project.id ? { ...p, contract_address: addr } : p));
      return addr;
    } catch (e) {
      console.error('ensureContractOnProject failed', e);
      throw e;
    }
  };

  const handleStartProject = async (project) => {
    const actionKey = `start_${project.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const contractAddress = project.contract_address || await ensureContractOnProject(project);

      const pk = user?.private_key || localStorage.getItem('freelance_private_key');
      if (!pk) {
        toast.error('Missing freelancer private key');
        return;
      }

      const txReceipt = await blockchain.startProject(contractAddress, pk);

      await api.updateProject(project.id, { status: 'in_progress' });
      toast.success(`Project started! Tx: ${txReceipt.transactionHash?.substring(0, 10) || txReceipt.transactionHash}...`);
      if (onUpdate) onUpdate(); else loadProjects();
    } catch (error) {
      console.error('Failed to start project:', error);
      toast.error(`Failed to start project: ${error.message || error}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const handleCompleteWork = async (project) => {
    setSelectedProject(project);
    setShowFileUploadModal(true);
    setUploadFiles([]);
    setUploadNotes('');
  };

  const handleFileUploadSubmit = async () => {
    if (!selectedProject) return;

    const actionKey = `complete_${selectedProject.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      if (uploadFiles.length > 0) {
        await api.uploadCompletionFiles(selectedProject.id, uploadFiles, uploadNotes);
        toast.success('Files uploaded successfully!');
      }

      const contractAddress = selectedProject.contract_address || await ensureContractOnProject(selectedProject);

      const pk = user?.private_key || localStorage.getItem('freelance_private_key');
      if (!pk) {
        toast.error('Missing freelancer private key');
        return;
      }

      const txReceipt = await blockchain.completeWork(contractAddress, pk);

      await api.updateProject(selectedProject.id, { status: 'completed' });
      toast.success(`Work completed! Tx: ${txReceipt.transactionHash?.substring(0, 10) || txReceipt.transactionHash}...`);

      setShowFileUploadModal(false);
      setSelectedProject(null);
      setUploadFiles([]);
      setUploadNotes('');

      if (onUpdate) onUpdate(); else loadProjects();
    } catch (error) {
      console.error('Failed to complete work:', error);
      toast.error(`Failed to complete work: ${error.message || error}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const handleFileChange = (e) => {
    const newFiles = Array.from(e.target.files);
    setUploadFiles(prev => [...prev, ...newFiles]);
  };

  const removeUploadFile = (index) => {
    setUploadFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleViewFiles = async (project) => {
    try {
      const filesData = await api.getCompletionFiles(project.id);
      setCompletionFiles(filesData);
      setSelectedProject(project);
      setShowFileViewModal(true);
    } catch (error) {
      toast.error('Failed to load completion files');
      console.error(error);
    }
  };

  const handleReleasePayment = async (project) => {
    const actionKey = `release_${project.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const contractAddress = project.contract_address || await ensureContractOnProject(project);

      const pk = user?.private_key || localStorage.getItem('freelance_private_key');
      if (!pk) {
        toast.error('Missing employer private key');
        return;
      }

      const txReceipt = await blockchain.releasePayment(contractAddress, pk);

      await api.updateProject(project.id, { status: 'paid' });
      toast.success(`Payment released! Tx: ${txReceipt.transactionHash?.substring(0, 10) || txReceipt.transactionHash}...`);
      if (onUpdate) onUpdate(); else loadProjects();
    } catch (error) {
      console.error('Failed to release payment:', error);
      toast.error(`Failed to release payment: ${error.message || error}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  // Request Redo
  const handleRequestRedo = (project) => {
    setSelectedProject(project);
    setRedoNote('');
    setShowRedoModal(true);
  };

  const handleRedoSubmit = async () => {
    if (!selectedProject) return;
    const actionKey = `redo_${selectedProject.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));
    try {
      await api.requestRedo(selectedProject.id, redoNote);
      toast.success('Revision requested. Freelancer has been asked to redo the work.');
      setShowRedoModal(false);
      setSelectedProject(null);
      setRedoNote('');
      if (onUpdate) onUpdate(); else loadProjects();
    } catch (error) {
      toast.error(`Failed to request redo: ${error.message}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  // Cancel Project
  const handleCancelProject = (project) => {
    setSelectedProject(project);
    setCancelReason('');
    setShowCancelModal(true);
  };

  const handleCancelSubmit = async () => {
    if (!selectedProject) return;
    const actionKey = `cancel_${selectedProject.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));
    try {
      await api.cancelProject(selectedProject.id, cancelReason);
      toast.success('Project has been cancelled.');
      setShowCancelModal(false);
      setSelectedProject(null);
      setCancelReason('');
      if (onUpdate) onUpdate(); else loadProjects();
    } catch (error) {
      toast.error(`Failed to cancel project: ${error.message}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  // View reference media
  const handleViewMedia = async (project) => {
    try {
      const data = await api.getProjectMedia(project.id);
      setProjectMedia(data.files || []);
      setSelectedProject(project);
      setShowMediaModal(true);
    } catch (error) {
      toast.error('Failed to load project media');
    }
  };

  const handleDeployContract = async (project) => {
    if (!user || user.user_type !== 'employer' || parseInt(project.employer_id) !== parseInt(user.id)) {
      toast.error('Not authorized to deploy this contract');
      return;
    }

    const employerPK = user?.private_key || localStorage.getItem('freelance_private_key');
    if (!employerPK) {
      toast.error('Missing employer private key in profile/localStorage');
      return;
    }

    let freelancerAddress = project.freelancer_wallet_address || project.freelancer_wallet || null;
    if (!freelancerAddress && project.freelancer_id) {
      try {
        const prof = await api.getFreelancerProfile(project.freelancer_id);
        if (prof && prof.wallet_address) freelancerAddress = prof.wallet_address;
      } catch (e) { /* ignore */ }

      if (!freelancerAddress) {
        try {
          const all = await api.getAllFreelancers();
          const found = all.find(f => parseInt(f.id) === parseInt(project.freelancer_id));
          if (found && found.wallet_address) freelancerAddress = found.wallet_address;
        } catch (e) { /* ignore */ }
      }
    }

    if (!freelancerAddress) {
      toast.error('Cannot find freelancer wallet address for this project');
      return;
    }

    setActionLoading(prev => ({ ...prev, [`deploy_${project.id}`]: true }));
    try {
      const contractData = {
        employer_private_key: employerPK,
        freelancer_address: freelancerAddress,
        job_description: project.description || project.title || 'job',
        amount: Number(project.budget) || 0
      };

      const res = await api.deployContract(contractData);
      const contractAddress = res?.contract_address || res?.contractAddress || res?.address;
      if (!contractAddress) throw new Error('No contract address returned from deploy API');

      await api.updateProject(project.id, { contract_address: contractAddress });

      toast.success(`Contract deployed: ${contractAddress.substring(0, 10)}...`);
      if (onUpdate) onUpdate(); else loadProjects();
    } catch (err) {
      console.error('Deploy failed', err);
      toast.error(`Deploy failed: ${err.message || err}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [`deploy_${project.id}`]: false }));
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  // Parse budget breakdown helper
  const parseBudgetBreakdown = (raw) => {
    if (!raw) return null;
    try { return JSON.parse(raw); } catch { return null; }
  };

  // Generate agreement reference number
  const agreementRef = (project) =>
    `AGR-${project?.id || '000'}-${new Date().getFullYear()}-${String(project?.employer_id || '0').padStart(4, '0')}`;

  if (loading) {
    return <div className="text-center py-8">Loading projects...</div>;
  }

  if (projects.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p className="text-gray-500">No projects found.</p>
          {availableProjects && (
            <p className="text-sm text-gray-400 mt-2">Check back later for new opportunities!</p>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      {/* ── Digital Agreement Modal ── */}
      {showAgreementModal && agreementProject && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 rounded-t-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                    <ScrollText className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Digital Agreement</h2>
                    <p className="text-blue-100 text-sm">Review and sign before accepting this project</p>
                  </div>
                </div>
                <button onClick={() => setShowAgreementModal(false)} className="text-white opacity-70 hover:opacity-100">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-5">
              {/* Agreement Reference */}
              <div className="flex items-center justify-between text-xs text-gray-500 bg-gray-50 rounded px-3 py-2 border">
                <span>Agreement Reference:</span>
                <span className="font-mono font-semibold text-gray-700">{agreementRef(agreementProject)}</span>
              </div>

              {/* Project Summary */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-2">
                <h3 className="font-semibold text-gray-900">{agreementProject.title}</h3>
                <p className="text-sm text-gray-600">{agreementProject.description}</p>
                <div className="flex flex-wrap gap-4 pt-2 text-sm">
                  <span className="flex items-center text-green-700 font-medium">
                    <DollarSign className="h-4 w-4 mr-1" />
                    ₹{agreementProject.budget}
                  </span>
                  {agreementProject.timeline && (
                    <span className="flex items-center text-blue-700">
                      <Calendar className="h-4 w-4 mr-1" />
                      {agreementProject.timeline}
                    </span>
                  )}
                  {agreementProject.required_skills && (
                    <span className="text-gray-600">Skills: {agreementProject.required_skills}</span>
                  )}
                </div>

                {/* Budget Breakdown */}
                {(() => {
                  const breakdown = parseBudgetBreakdown(agreementProject.budget_breakdown);
                  if (!breakdown || breakdown.length === 0) return null;
                  return (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <p className="text-xs font-semibold text-gray-600 mb-2 flex items-center gap-1">
                        <SplitSquareHorizontal className="h-3.5 w-3.5" />
                        Payment Breakdown
                      </p>
                      <div className="space-y-1">
                        {breakdown.map((item, i) => (
                          <div key={i} className="flex justify-between text-sm">
                            <span className="text-gray-600">{item.label}</span>
                            <span className="font-medium text-green-700">₹{Number(item.amount).toFixed(2)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between text-sm font-semibold border-t pt-1 mt-1">
                          <span>Total</span>
                          <span className="text-green-700">₹{agreementProject.budget}</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Agreement Terms */}
              <div className="border border-blue-100 rounded-lg overflow-hidden">
                <div className="bg-blue-50 px-4 py-3 flex items-center space-x-2">
                  <Shield className="h-4 w-4 text-blue-600" />
                  <span className="font-semibold text-blue-800 text-sm">Terms & Conditions</span>
                </div>
                <div className="p-4 space-y-3 text-sm text-gray-700 max-h-52 overflow-y-auto">
                  <p><strong>1. Work Commitment</strong><br />By accepting this agreement, I commit to delivering the project as described, within the agreed timeline and budget.</p>
                  <p><strong>2. Quality Standards</strong><br />I agree to maintain professional quality standards and communicate proactively about any issues or delays.</p>
                  <p><strong>3. Smart Contract Escrow</strong><br />Payment will be held in a blockchain escrow smart contract and released only after the client approves the completed work.</p>
                  <p><strong>4. Revision Policy</strong><br />The client may request a revision if work does not meet the agreed specifications. The freelancer commits to addressing feedback promptly.</p>
                  <p><strong>5. Intellectual Property</strong><br />All deliverables produced for this project become the property of the client upon full payment release.</p>
                  <p><strong>6. Cancellation</strong><br />Either party may cancel the project before work begins. Once in progress, cancellation requires mutual agreement and may affect escrow release.</p>
                  <p><strong>7. Confidentiality</strong><br />I agree to keep all project details, client information, and related materials strictly confidential.</p>
                  <p><strong>8. Platform Compliance</strong><br />I agree to comply with all FreelancerX platform policies and applicable laws.</p>
                </div>
              </div>

              {/* Checkbox */}
              <label className="flex items-start space-x-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={agreementChecked}
                  onChange={(e) => setAgreementChecked(e.target.checked)}
                  className="mt-1 h-4 w-4 accent-blue-600 cursor-pointer"
                />
                <span className="text-sm text-gray-700 group-hover:text-gray-900">
                  I have read and agree to the terms and conditions of this digital agreement. I understand this creates a binding commitment on the FreelancerX platform.
                </span>
              </label>

              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setShowAgreementModal(false)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  disabled={!agreementChecked || actionLoading[`apply_${agreementProject.id}`]}
                  onClick={() => handleApply(agreementProject.id)}
                >
                  {actionLoading[`apply_${agreementProject.id}`] ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Signing...</>
                  ) : (
                    <><CheckCircle className="h-4 w-4 mr-2" />Sign & Accept</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Chat Modal ── */}
      {showChatModal && selectedProject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex justify-between items-center p-4 border-b">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Project Chat</h2>
                <p className="text-sm text-gray-500">{selectedProject.title}</p>
              </div>
              <button
                onClick={() => { setShowChatModal(false); setSelectedProject(null); }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            {selectedProject.status === 'open' && user.user_type === 'freelancer' && (
              <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 text-sm text-blue-700 flex items-center gap-2">
                <Shield className="h-4 w-4 shrink-0" />
                Discuss the project here. When you're ready to commit, close the chat and click <strong className="mx-1">Apply</strong> on the project card.
              </div>
            )}
            <div className="p-4">
              <ChatComponent projectId={selectedProject.id} projectTitle={selectedProject.title} />
            </div>
            <div className="flex justify-end p-4 border-t">
              <Button variant="outline" onClick={() => { setShowChatModal(false); setSelectedProject(null); }}>
                <X className="h-4 w-4 mr-2" />Close Chat
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ── File Upload Modal (Completion) ── */}
      {showFileUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-900">Complete Project & Upload Files</h2>
                <button
                  onClick={() => { setShowFileUploadModal(false); setSelectedProject(null); setUploadFiles([]); setUploadNotes(''); }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="file-upload" className="block text-sm font-medium text-gray-700 mb-2">
                    Upload Completion Files — Images, Videos, Documents, Code Archives
                  </Label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-blue-400 transition-colors">
                    <div className="space-y-1 text-center">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500">
                          <span>Upload files</span>
                          <Input
                            id="file-upload"
                            name="file-upload"
                            type="file"
                            className="sr-only"
                            multiple
                            onChange={handleFileChange}
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">PNG, JPG, PDF, DOC, ZIP up to 10MB each — multiple files supported</p>
                    </div>
                  </div>

                  {uploadFiles.length > 0 && (
                    <div className="mt-4">
                      <p className="text-sm font-medium text-gray-700 mb-2">Selected Files ({uploadFiles.length}):</p>
                      <ul className="space-y-2">
                        {uploadFiles.map((file, index) => (
                          <li key={index} className="flex items-center justify-between text-sm text-gray-600 bg-gray-50 p-2 rounded">
                            <span className="flex items-center truncate">
                              <FileText className="h-4 w-4 mr-2 text-blue-500 shrink-0" />
                              {file.name} ({(file.size / 1024).toFixed(2)} KB)
                            </span>
                            <button
                              type="button"
                              onClick={() => removeUploadFile(index)}
                              className="text-red-400 hover:text-red-600 ml-2 shrink-0"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="completion-notes" className="block text-sm font-medium text-gray-700 mb-2">
                    Completion Notes (Optional)
                  </Label>
                  <Textarea
                    id="completion-notes"
                    rows={4}
                    className="w-full"
                    placeholder="Summarise what was delivered, any known issues, or deployment instructions..."
                    value={uploadNotes}
                    onChange={(e) => setUploadNotes(e.target.value)}
                  />
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => { setShowFileUploadModal(false); setSelectedProject(null); setUploadFiles([]); setUploadNotes(''); }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleFileUploadSubmit}
                    disabled={actionLoading[`complete_${selectedProject?.id}`]}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {actionLoading[`complete_${selectedProject?.id}`] ? (
                      <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Completing...</>
                    ) : (
                      <><CheckCircle className="h-4 w-4 mr-2" />Complete Project</>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── File View Modal ── */}
      {showFileViewModal && completionFiles && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-900">Completion Files & Notes</h2>
                <button onClick={() => { setShowFileViewModal(false); setSelectedProject(null); setCompletionFiles(null); }} className="text-gray-400 hover:text-gray-600">
                  <X className="h-6 w-6" />
                </button>
              </div>

              {/* Revision info */}
              {selectedProject?.revision_request && (
                <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
                  <strong>Last Revision Request:</strong> {selectedProject.revision_request}
                  {selectedProject.revision_count > 0 && (
                    <span className="ml-2 text-amber-600">(Revision #{selectedProject.revision_count})</span>
                  )}
                </div>
              )}

              <div className="space-y-4">
                {completionFiles.notes && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold text-blue-900 mb-2">Completion Notes:</h3>
                    <p className="text-blue-800">{completionFiles.notes}</p>
                  </div>
                )}

                {completionFiles.files && completionFiles.files.length > 0 ? (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Uploaded Files ({completionFiles.files.length}):</h3>
                    <div className="space-y-2">
                      {completionFiles.files.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center space-x-3">
                            <FileText className="h-6 w-6 text-blue-500" />
                            <div>
                              <p className="font-medium text-gray-900">{file.filename}</p>
                              <p className="text-sm text-gray-500">
                                {(file.size / 1024).toFixed(2)} KB • {new Date(file.upload_date).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <a
                            href={api.getFileDownloadUrl(selectedProject.id, file.stored_filename)}
                            download={file.filename}
                            className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-medium"
                          >
                            <Download className="h-5 w-5" />
                            <span>Download</span>
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-4">No files uploaded yet</p>
                )}

                <div className="flex justify-end pt-4">
                  <Button variant="outline" onClick={() => { setShowFileViewModal(false); setSelectedProject(null); setCompletionFiles(null); }}>
                    Close
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Request Redo Modal ── */}
      {showRedoModal && selectedProject && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-5 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                  <RotateCcw className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Request Revision</h2>
                  <p className="text-amber-100 text-sm">Ask the freelancer to redo the work</p>
                </div>
              </div>
              <button onClick={() => setShowRedoModal(false)} className="text-white opacity-70 hover:opacity-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
                <AlertTriangle className="h-4 w-4 inline mr-1" />
                The project will revert to <strong>In Progress</strong>. The freelancer will need to re-submit the work.
              </div>
              <div>
                <Label className="text-sm font-medium">What needs to be changed? *</Label>
                <Textarea
                  rows={4}
                  placeholder="Describe clearly what needs to be revised or redone..."
                  value={redoNote}
                  onChange={(e) => setRedoNote(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setShowRedoModal(false)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-amber-500 hover:bg-amber-600"
                  disabled={!redoNote.trim() || actionLoading[`redo_${selectedProject.id}`]}
                  onClick={handleRedoSubmit}
                >
                  {actionLoading[`redo_${selectedProject.id}`] ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Requesting...</>
                  ) : (
                    <><RotateCcw className="h-4 w-4 mr-2" />Request Revision</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Cancel Project Modal ── */}
      {showCancelModal && selectedProject && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="bg-gradient-to-r from-red-500 to-rose-600 p-5 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                  <Ban className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Cancel Project</h2>
                  <p className="text-red-100 text-sm">This action cannot be undone</p>
                </div>
              </div>
              <button onClick={() => setShowCancelModal(false)} className="text-white opacity-70 hover:opacity-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
                <AlertTriangle className="h-4 w-4 inline mr-1" />
                The project will be marked as <strong>Cancelled</strong>. If a smart contract was deployed, you may need to manually handle the escrow refund on the blockchain.
              </div>
              <div>
                <Label className="text-sm font-medium">Reason for Cancellation (optional)</Label>
                <Textarea
                  rows={3}
                  placeholder="Provide a reason for cancelling this project..."
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setShowCancelModal(false)}>
                  Keep Project
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  disabled={actionLoading[`cancel_${selectedProject.id}`]}
                  onClick={handleCancelSubmit}
                >
                  {actionLoading[`cancel_${selectedProject.id}`] ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Cancelling...</>
                  ) : (
                    <><Ban className="h-4 w-4 mr-2" />Cancel Project</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Media Files Modal ── */}
      {showMediaModal && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <Image className="h-5 w-5 text-purple-600" />
                  Project Reference Media
                </h2>
                <button onClick={() => { setShowMediaModal(false); setSelectedProject(null); setProjectMedia([]); }} className="text-gray-400 hover:text-gray-600">
                  <X className="h-6 w-6" />
                </button>
              </div>
              {projectMedia.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No reference media uploaded for this project.</p>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {projectMedia.map((file, index) => {
                    const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(file.filename);
                    const fileUrl = api.getProjectMediaUrl(selectedProject.id, file.stored_filename);
                    return (
                      <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                        {isImage ? (
                          <img src={fileUrl} alt={file.filename} className="w-full h-32 object-cover" />
                        ) : (
                          <div className="w-full h-32 bg-gray-50 flex items-center justify-center">
                            <FileText className="h-10 w-10 text-gray-400" />
                          </div>
                        )}
                        <div className="p-2 flex items-center justify-between">
                          <span className="text-xs text-gray-600 truncate max-w-[120px]">{file.filename}</span>
                          <a href={fileUrl} download={file.filename} className="text-blue-500 hover:text-blue-700">
                            <Download className="h-4 w-4" />
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              <div className="flex justify-end mt-4">
                <Button variant="outline" onClick={() => { setShowMediaModal(false); setSelectedProject(null); setProjectMedia([]); }}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Project Cards ── */}
      <div className="space-y-4">
        {Array.isArray(projects) && projects.map((project) => {
          const breakdown = parseBudgetBreakdown(project.budget_breakdown);
          const isCancelled = project.status === 'cancelled';
          const isEmployerOwner = user.user_type === 'employer' && parseInt(project.employer_id) === parseInt(user.id);
          const isAssignedFreelancer = user.user_type === 'freelancer' && parseInt(project.freelancer_id) === parseInt(user.id);

          return (
            <Card key={project.id} className={`hover:shadow-md transition-shadow ${isCancelled ? 'opacity-60' : ''}`}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{project.title || 'Untitled Project'}</CardTitle>
                    <p className="text-gray-600 mt-2">{project.description || 'No description available'}</p>
                  </div>
                  <div className="ml-4 flex flex-col items-end gap-1">
                    {getStatusBadge(project.status || 'open')}
                    {project.revision_count > 0 && (
                      <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                        Rev. #{project.revision_count}
                      </span>
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-6 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <DollarSign className="h-4 w-4" />
                      <span className="font-medium">₹{project.budget || 0}</span>
                    </div>
                    {project.created_at && (
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(project.created_at).toLocaleDateString()}</span>
                      </div>
                    )}
                    {project.freelancer_id && user.user_type === 'employer' && (
                      <div className="flex items-center space-x-1">
                        <User className="h-4 w-4" />
                        <span>Freelancer assigned</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Budget Breakdown */}
                {breakdown && breakdown.length > 0 && (
                  <div className="mb-4 p-3 bg-indigo-50 border border-indigo-100 rounded-lg">
                    <p className="text-xs font-semibold text-indigo-700 mb-2 flex items-center gap-1">
                      <SplitSquareHorizontal className="h-3.5 w-3.5" />
                      Payment Breakdown
                    </p>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                      {breakdown.map((item, i) => (
                        <div key={i} className="flex justify-between text-xs text-gray-700">
                          <span>{item.label}</span>
                          <span className="font-medium">₹{Number(item.amount).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Revision Request Banner */}
                {project.revision_request && project.status === 'in_progress' && (
                  <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800">
                    <strong>Revision Requested:</strong> {project.revision_request}
                  </div>
                )}

                {/* Smart Contract Info */}
                {project.contract_address && (
                  <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Smart Contract:</span>
                      <Button variant="ghost" size="sm" onClick={() => copyToClipboard(project.contract_address)}>
                        <Copy className="h-3 w-3 mr-1" />
                        {project.contract_address.substring(0, 10)}...
                      </Button>
                    </div>
                  </div>
                )}

                <Separator className="my-4" />

                {/* Action Buttons */}
                <div className="flex gap-2 flex-wrap">

                  {/* ── Chat: open to ALL freelancers on open projects + involved parties ── */}
                  {!isCancelled && (
                    (project.status === 'open' && user.user_type === 'freelancer') ||
                    ((project.status === 'assigned' || project.status === 'pending' ||
                      project.status === 'in_progress' || project.status === 'completed' ||
                      project.status === 'paid') &&
                      (isEmployerOwner || isAssignedFreelancer))
                  ) && (
                    <Button
                      variant="outline"
                      onClick={() => openChat(project)}
                      className="border-green-500 text-green-600 hover:bg-green-50 relative"
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {project.status === 'open' ? 'Discuss' : 'Chat'}
                      {unreadCounts[project.id] > 0 && (
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                          {unreadCounts[project.id]}
                        </span>
                      )}
                    </Button>
                  )}

                  {/* Media button — visible to all when media exists */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleViewMedia(project)}
                    className="text-purple-600 hover:bg-purple-50"
                  >
                    <ImageIcon className="h-4 w-4 mr-1" />
                    Refs
                  </Button>

                  {/* ── Freelancer Actions ── */}
                  {user.user_type === 'freelancer' && (
                    <>
                      {/* Apply: shown on open projects with no assigned freelancer yet */}
                      {project.status === 'open' && !project.freelancer_id && (showApply || availableProjects) && (
                        <Button
                          onClick={() => openAgreementModal(project)}
                          disabled={actionLoading[`apply_${project.id}`]}
                        >
                          {actionLoading[`apply_${project.id}`] ? 'Signing...' : 'Apply'}
                        </Button>
                      )}

                      {/* Already reserved by another freelancer */}
                      {project.status === 'open' && project.freelancer_id && !isAssignedFreelancer && (
                        <span className="text-xs text-gray-400 italic self-center">Negotiation in progress</span>
                      )}

                      {/* Start Project: from 'pending' or 'assigned' */}
                      {(project.status === 'pending' || project.status === 'assigned') && isAssignedFreelancer && (
                        <Button
                          onClick={() => handleStartProject(project)}
                          disabled={actionLoading[`start_${project.id}`]}
                          variant="outline"
                          className="border-blue-500 text-blue-600 hover:bg-blue-50"
                        >
                          {actionLoading[`start_${project.id}`] ? (
                            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Starting...</>
                          ) : (
                            <><Play className="h-4 w-4 mr-2" />Start Project</>
                          )}
                        </Button>
                      )}

                      {/* Mark Complete */}
                      {project.status === 'in_progress' && isAssignedFreelancer && (
                        <Button
                          onClick={() => handleCompleteWork(project)}
                          disabled={actionLoading[`complete_${project.id}`]}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {actionLoading[`complete_${project.id}`] ? (
                            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Completing...</>
                          ) : (
                            <><CheckCircle className="h-4 w-4 mr-2" />Mark Complete</>
                          )}
                        </Button>
                      )}
                    </>
                  )}

                  {/* ── Employer Actions ── */}
                  {isEmployerOwner && (
                    <>
                      {/* Deploy Contract: show for pending/assigned with no contract */}
                      {(project.status === 'pending' || project.status === 'assigned') && !project.contract_address && (
                        <Button
                          onClick={() => handleDeployContract(project)}
                          disabled={actionLoading[`deploy_${project.id}`]}
                          variant="outline"
                        >
                          {actionLoading[`deploy_${project.id}`] ? 'Deploying...' : 'Deploy Contract'}
                        </Button>
                      )}

                      {/* Completed: view files, release payment, request redo, cancel */}
                      {project.status === 'completed' && (
                        <>
                          <Button
                            variant="outline"
                            onClick={() => handleViewFiles(project)}
                            className="border-blue-500 text-blue-600 hover:bg-blue-50"
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Files
                          </Button>
                          <Button
                            onClick={() => handleReleasePayment(project)}
                            disabled={actionLoading[`release_${project.id}`]}
                            className="bg-emerald-600 hover:bg-emerald-700"
                          >
                            {actionLoading[`release_${project.id}`] ? (
                              <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Releasing...</>
                            ) : (
                              <><DollarSign className="h-4 w-4 mr-2" />Release Payment</>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => handleRequestRedo(project)}
                            disabled={actionLoading[`redo_${project.id}`]}
                            className="border-amber-500 text-amber-600 hover:bg-amber-50"
                          >
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Request Redo
                          </Button>
                        </>
                      )}

                      {/* Cancel: available unless paid */}
                      {project.status !== 'paid' && project.status !== 'cancelled' && (
                        <Button
                          variant="outline"
                          onClick={() => handleCancelProject(project)}
                          disabled={actionLoading[`cancel_${project.id}`]}
                          className="border-red-300 text-red-500 hover:bg-red-50"
                        >
                          <Ban className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                      )}
                    </>
                  )}
                </div>

                {/* Additional Project Info */}
                {(project.required_skills || project.timeline) && (
                  <div className="mt-4 pt-4 border-t">
                    {project.required_skills && (
                      <div className="mb-2">
                        <span className="text-sm font-medium text-gray-700">Skills: </span>
                        <span className="text-sm text-gray-600">{project.required_skills}</span>
                      </div>
                    )}
                    {project.timeline && (
                      <div>
                        <span className="text-sm font-medium text-gray-700">Timeline: </span>
                        <span className="text-sm text-gray-600">{project.timeline}</span>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </>
  );
}
