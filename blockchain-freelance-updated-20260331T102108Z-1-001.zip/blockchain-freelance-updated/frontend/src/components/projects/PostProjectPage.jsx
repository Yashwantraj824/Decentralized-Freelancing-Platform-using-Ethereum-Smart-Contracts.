import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle, ArrowLeft, PlusCircle, Trash2, Upload, FileText, SplitSquareHorizontal, Image } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import api from '../../services/api';

export default function PostProjectPage({ setCurrentPage }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    budget: '',
    requiredSkills: '',
    timeline: '',
    requirements: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Split budget state
  const [splitEnabled, setSplitEnabled] = useState(false);
  const [budgetItems, setBudgetItems] = useState([
    { label: 'Frontend', amount: '' },
    { label: 'Backend', amount: '' }
  ]);

  // Media upload state
  const [mediaFiles, setMediaFiles] = useState([]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError('');
    setSuccess(false);
  };

  // Compute total from budget items
  const splitTotal = budgetItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

  const addBudgetItem = () => {
    setBudgetItems(prev => [...prev, { label: '', amount: '' }]);
  };

  const removeBudgetItem = (index) => {
    setBudgetItems(prev => prev.filter((_, i) => i !== index));
  };

  const updateBudgetItem = (index, field, value) => {
    setBudgetItems(prev => prev.map((item, i) => i === index ? { ...item, [field]: value } : item));
  };

  const handleMediaChange = (e) => {
    const files = Array.from(e.target.files);
    setMediaFiles(prev => [...prev, ...files]);
  };

  const removeMediaFile = (index) => {
    setMediaFiles(prev => prev.filter((_, i) => i !== index));
  };

  const validateForm = () => {
    if (!formData.title.trim()) return 'Project title is required';
    if (!formData.description.trim()) return 'Project description is required';
    if (splitEnabled) {
      if (budgetItems.length === 0) return 'Add at least one payment component';
      for (const item of budgetItems) {
        if (!item.label.trim()) return 'Each payment component needs a label';
        if (!item.amount || Number(item.amount) <= 0) return 'Each payment component needs a valid amount';
      }
      if (splitTotal <= 0) return 'Total budget must be greater than 0';
    } else {
      if (!formData.budget || Number(formData.budget) <= 0) return 'Please enter a valid budget amount';
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const finalBudget = splitEnabled ? splitTotal : Number(formData.budget);
      const budgetBreakdown = splitEnabled
        ? JSON.stringify(budgetItems.filter(i => i.label && i.amount))
        : null;

      const projectData = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        budget: finalBudget,
        employer_id: user.id,
        required_skills: formData.requiredSkills.trim(),
        timeline: formData.timeline.trim(),
        requirements: formData.requirements.trim(),
        budget_breakdown: budgetBreakdown
      };

      const createdProject = await api.createProject(projectData);

      // Upload reference media if any
      if (mediaFiles.length > 0 && createdProject?.id) {
        try {
          await api.uploadProjectMedia(createdProject.id, mediaFiles);
        } catch (mediaErr) {
          toast.error('Project created but some media files failed to upload');
        }
      }

      setSuccess(true);
      toast.success('Project posted successfully!');
      setFormData({ title: '', description: '', budget: '', requiredSkills: '', timeline: '', requirements: '' });
      setBudgetItems([{ label: 'Frontend', amount: '' }, { label: 'Backend', amount: '' }]);
      setSplitEnabled(false);
      setMediaFiles([]);

      setTimeout(() => {
        if (setCurrentPage) setCurrentPage('my-projects');
      }, 1500);
    } catch (err) {
      setError(err.message || 'Failed to post project');
      toast.error('Failed to post project');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFormData({ title: '', description: '', budget: '', requiredSkills: '', timeline: '', requirements: '' });
    setBudgetItems([{ label: 'Frontend', amount: '' }, { label: 'Backend', amount: '' }]);
    setSplitEnabled(false);
    setMediaFiles([]);
    setError('');
    setSuccess(false);
  };

  return (
    <div className="max-w-3xl mx-auto">
      {setCurrentPage && (
        <Button
          variant="ghost"
          className="mb-4 text-gray-600 hover:text-gray-900"
          onClick={() => setCurrentPage('dashboard')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
      )}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Post a Project Requirement</CardTitle>
          <CardDescription>Describe what you need built — freelancers will apply to work on it</CardDescription>
        </CardHeader>

        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">Project posted successfully!</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="title">Project Title *</Label>
              <Input id="title" name="title" value={formData.title} onChange={handleInputChange} placeholder="Enter a clear, descriptive project title" required />
            </div>

            <div>
              <Label htmlFor="description">Project Description *</Label>
              <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} placeholder="Describe your project..." rows={4} required />
            </div>

            {/* Budget Section */}
            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Budget *</Label>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={splitEnabled}
                    onChange={(e) => setSplitEnabled(e.target.checked)}
                    className="h-4 w-4 accent-blue-600"
                  />
                  <span className="text-sm text-blue-700 font-medium flex items-center gap-1">
                    <SplitSquareHorizontal className="h-4 w-4" />
                    Split Payment
                  </span>
                </label>
              </div>

              {!splitEnabled ? (
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500 text-sm">₹</span>
                    <Input
                      id="budget"
                      name="budget"
                      type="number"
                      min="0"
                      step="0.0001"
                      value={formData.budget}
                      onChange={handleInputChange}
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Amount will be held in smart contract escrow</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-gray-500">Break down the total payment by work components. Each part becomes a separate line in the agreement.</p>
                  {budgetItems.map((item, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        placeholder="Component (e.g. Frontend)"
                        value={item.label}
                        onChange={(e) => updateBudgetItem(index, 'label', e.target.value)}
                        className="flex-1"
                      />
                      <div className="flex items-center gap-1 w-36">
                        <span className="text-gray-500 text-sm">₹</span>
                        <Input
                          type="number"
                          min="0"
                          step="0.0001"
                          placeholder="Amount"
                          value={item.amount}
                          onChange={(e) => updateBudgetItem(index, 'amount', e.target.value)}
                        />
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeBudgetItem(index)}
                        disabled={budgetItems.length <= 1}
                        className="text-red-500 hover:text-red-700 px-2"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-1">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addBudgetItem}
                      className="text-blue-600 border-blue-300 hover:bg-blue-50"
                    >
                      <PlusCircle className="h-4 w-4 mr-1" />
                      Add Component
                    </Button>
                    <div className="text-sm font-semibold text-green-700 bg-green-50 border border-green-200 rounded px-3 py-1">
                      Total: ₹{splitTotal.toFixed(2)}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="timeline">Expected Timeline</Label>
              <Input id="timeline" name="timeline" value={formData.timeline} onChange={handleInputChange} placeholder="e.g., 2-3 weeks, 1 month" />
            </div>

            <div>
              <Label htmlFor="requiredSkills">Required Skills</Label>
              <Input id="requiredSkills" name="requiredSkills" value={formData.requiredSkills} onChange={handleInputChange} placeholder="e.g., React, Node.js, Smart Contracts" />
              <p className="text-xs text-gray-500 mt-1">Comma-separated list of skills (used for freelancer matching)</p>
            </div>

            <div>
              <Label htmlFor="requirements">Additional Requirements</Label>
              <Textarea id="requirements" name="requirements" value={formData.requirements} onChange={handleInputChange} placeholder="Any additional requirements..." rows={3} />
            </div>

            {/* Reference Media Upload */}
            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <Label className="text-base font-semibold flex items-center gap-2">
                <Image className="h-4 w-4 text-purple-600" />
                Reference Media (Optional)
              </Label>
              <p className="text-xs text-gray-500">Upload mockups, designs, or reference files to help freelancers understand the project.</p>
              <div className="flex justify-center px-4 pt-4 pb-4 border-2 border-dashed border-gray-300 rounded-md hover:border-purple-400 transition-colors">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-8 w-8 text-gray-400" />
                  <label className="cursor-pointer text-sm text-purple-600 hover:text-purple-500 font-medium">
                    <span>Upload reference files</span>
                    <input
                      type="file"
                      multiple
                      accept="image/*,.pdf,.doc,.docx,.txt,.zip"
                      className="sr-only"
                      onChange={handleMediaChange}
                    />
                  </label>
                  <p className="text-xs text-gray-500">Images, PDFs, Docs up to 10MB each</p>
                </div>
              </div>
              {mediaFiles.length > 0 && (
                <ul className="space-y-1">
                  {mediaFiles.map((file, index) => (
                    <li key={index} className="flex items-center justify-between bg-gray-50 rounded px-3 py-1.5 text-sm">
                      <span className="flex items-center gap-2 text-gray-700 truncate max-w-xs">
                        <FileText className="h-4 w-4 text-purple-500 shrink-0" />
                        {file.name}
                      </span>
                      <button
                        type="button"
                        onClick={() => removeMediaFile(index)}
                        className="text-red-400 hover:text-red-600 ml-2 shrink-0"
                      >
                        ✕
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? 'Posting...' : 'Post Requirement'}
              </Button>

              <Button type="button" variant="outline" onClick={handleReset} disabled={loading}>
                Reset
              </Button>

              {setCurrentPage && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentPage('dashboard')}
                  disabled={loading}
                >
                  Cancel
                </Button>
              )}
            </div>

            <div className="text-xs text-gray-500 space-y-1">
              <p>• Once posted, your requirement will be visible to all freelancers on the platform</p>
              <p>• Freelancers can chat with you before applying — you agree and then they start</p>
              <p>• A one-time payment smart contract is deployed when a freelancer agrees to work</p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
