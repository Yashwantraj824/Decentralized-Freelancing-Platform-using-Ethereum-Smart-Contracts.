import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Star, DollarSign, Clock, User, Zap, Target, Award, Shield, Sparkles, Filter, Wallet } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import api from '../../services/api';
import blockchain from '../../services/blockchain';

export default function FindFreelancersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [searchParams, setSearchParams] = useState({
    description: '',
    skills: ''
  });
  const [matchedFreelancers, setMatchedFreelancers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);
  const [hiring, setHiring] = useState(null);
  const [sortBy, setSortBy] = useState('match');
  const [filters, setFilters] = useState({
    minExperience: '',
    maxRate: '',
    skills: []
  });

  useEffect(() => {
    if (user?.id) {
      loadProjects();
    }
  }, [user]);

  const loadProjects = async () => {
    if (!user?.id) {
      toast.error('User not authenticated');
      return;
    }

    try {
      setLoading(true);
      const userId = parseInt(user.id);
      const data = await api.getProjects({ employer_id: userId, status: 'open' });
      setProjects(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to load projects:', error);
      toast.error('Failed to load projects');
      setProjects([]);
    } finally {
      setLoading(false);
    }
  };

  const handleProjectSelect = (projectId) => {
    const project = projects.find(p => p.id.toString() === projectId);
    if (project) {
      setSelectedProject(projectId);
      setSearchParams({
        description: project.description || '',
        skills: project.required_skills || ''
      });
    }
  };

  const handleSearch = async () => {
    if (!searchParams.description.trim()) {
      toast.error('Please enter a project description');
      return;
    }

    setSearching(true);
    try {
      const freelancers = await api.matchFreelancers(
        searchParams.description,
        searchParams.skills
      );
      setMatchedFreelancers(Array.isArray(freelancers) ? freelancers : []);
      
      if (freelancers.length === 0) {
        toast.warning('No freelancers found matching your requirements');
      } else {
        toast.success(`Found ${freelancers.length} matching freelancers`);
      }
    } catch (error) {
      console.error('Search failed:', error);
      toast.error('Failed to search freelancers');
      setMatchedFreelancers([]);
    } finally {
      setSearching(false);
    }
  };

  const handleHire = async (freelancer) => {
    if (!selectedProject) {
      toast.error('Please select a project first');
      return;
    }

    const project = projects.find(p => p.id.toString() === selectedProject);
    if (!project) {
      toast.error('Selected project not found');
      return;
    }

    const projectId = parseInt(project.id);
    const freelancerId = parseInt(freelancer.id);

    setHiring(freelancerId);
    
    try {
      toast.info('Deploying smart contract...');
      
      const contractAddress = await blockchain.deployContract(
        user.private_key,
        freelancer.wallet_address,
        project.description,
        project.budget
      );

      await api.updateProject(projectId, {
        freelancer_id: freelancerId,
        status: 'assigned',
        contract_address: contractAddress
      });

      toast.success(`Hired ${freelancer.username}! Contract deployed at ${contractAddress.substring(0, 10)}...`);
      
      await loadProjects();
      setMatchedFreelancers([]);
      setSelectedProject('');
      setSearchParams({ description: '', skills: '' });

    } catch (error) {
      console.error('Hiring failed:', error);
      toast.error(`Failed to hire freelancer: ${error.message}`);
    } finally {
      setHiring(null);
    }
  };

  const filteredFreelancers = matchedFreelancers
    .filter(freelancer => {
      if (filters.minExperience && freelancer.experience < parseInt(filters.minExperience)) return false;
      if (filters.maxRate && freelancer.hourly_rate > parseFloat(filters.maxRate)) return false;
      if (filters.skills.length > 0) {
        const freelancerSkills = freelancer.skills?.toLowerCase().split(',').map(s => s.trim()) || [];
        return filters.skills.some(skill => freelancerSkills.includes(skill.toLowerCase()));
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'match') return (b.match_score || 0) - (a.match_score || 0);
      if (sortBy === 'rate') return a.hourly_rate - b.hourly_rate;
      if (sortBy === 'experience') return b.experience - a.experience;
      return 0;
    });

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md border">
          <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600">Please log in to find freelancers</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your projects...</p>
          <p className="text-sm text-gray-500 mt-2">Preparing to find the best talent</p>
        </div>
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center p-6">
        <div className="max-w-md mx-auto text-center bg-white p-8 rounded-xl shadow-lg border">
          <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
            <Target className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-3">Find Top Talent</h1>
          <p className="text-gray-600 mb-6">
            You need to post a project before you can hire freelancers. Create your first project to get started.
          </p>
          <Button 
            onClick={() => window.location.hash = '#/post-project'}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <Zap className="h-4 w-4 mr-2" />
            Post Your First Project
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Find <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Top Talent</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover skilled freelancers and hire with blockchain-powered smart contracts
          </p>
        </div>

        {/* Search Section */}
        <Card className="border-0 shadow-lg overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b">
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2 text-blue-600" />
              Search for Freelancers
            </CardTitle>
            <CardDescription>
              Select a project and customize the search criteria to find the perfect match
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="project" className="text-gray-700 mb-2 block">Select Project to Hire For</Label>
                <Select value={selectedProject} onValueChange={handleProjectSelect}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose a project..." />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id.toString()}>
                        <div className="flex items-center justify-between">
                          <span className="truncate">{project.title}</span>
                          <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                            ₹{project.budget}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="skills" className="text-gray-700 mb-2 block">Required Skills</Label>
                <Input
                  id="skills"
                  value={searchParams.skills}
                  onChange={(e) => setSearchParams(prev => ({ ...prev, skills: e.target.value }))}
                  placeholder="e.g., React, Node.js, Smart Contracts"
                  className="w-full"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description" className="text-gray-700 mb-2 block">Project Description</Label>
              <Textarea
                id="description"
                value={searchParams.description}
                onChange={(e) => setSearchParams(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe your project requirements, goals, and what you're looking for in a freelancer..."
                rows={4}
                className="w-full resize-none"
              />
            </div>

            <Button 
              onClick={handleSearch} 
              disabled={searching || !searchParams.description.trim()} 
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-3 text-base font-medium"
            >
              {searching ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Searching...
                </>
              ) : (
                <>
                  <Search className="h-5 w-5 mr-2" />
                  Find Matching Freelancers
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        {matchedFreelancers.length > 0 && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <h2 className="text-2xl font-bold text-gray-900">
                Matched Freelancers <span className="text-blue-600">({filteredFreelancers.length})</span>
              </h2>
              
              <div className="flex items-center space-x-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="match">Best Match</SelectItem>
                    <SelectItem value="rate">Hourly Rate</SelectItem>
                    <SelectItem value="experience">Experience</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-6">
              {filteredFreelancers.map((freelancer) => (
                <Card key={freelancer.id} className="border-0 shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Freelancer Info */}
                      <div className="flex-1">
                        <div className="flex items-start space-x-4 mb-4">
                          <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-12 h-12 flex items-center justify-center text-white font-bold text-lg">
                            {freelancer.username?.charAt(0).toUpperCase() || 'F'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold text-gray-900 truncate">
                                {freelancer.username}
                              </h3>
                              {freelancer.match_score && (
                                <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                                  <Star className="h-3 w-3 mr-1 fill-current" />
                                  {(freelancer.match_score * 100).toFixed(0)}% match
                                </Badge>
                              )}
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mb-4">
                              {freelancer.skills?.split(',').slice(0, 4).map((skill, index) => (
                                <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {skill.trim()}
                                </Badge>
                              ))}
                              {freelancer.skills?.split(',').length > 4 && (
                                <Badge variant="outline" className="bg-gray-100 text-gray-600">
                                  +{freelancer.skills.split(',').length - 4} more
                                </Badge>
                              )}
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                              <div className="flex items-center text-gray-600">
                                <Clock className="h-4 w-4 mr-2 text-blue-500" />
                                <span>{freelancer.experience || 0} years experience</span>
                              </div>
                              <div className="flex items-center text-gray-600">
                                <Wallet className="h-4 w-4 mr-2 text-green-500" />
                                <span className="font-mono">{freelancer.wallet_address?.substring(0, 8)}...{freelancer.wallet_address?.substring(freelancer.wallet_address.length - 6)}</span>
                              </div>
                            </div>

                            {freelancer.bio && (
                              <div className="mt-4">
                                <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">
                                  {freelancer.bio}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action Section */}
                      <div className="lg:w-48 flex flex-col justify-between space-y-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-gray-900 flex items-center justify-center">
                            <DollarSign className="h-5 w-5 text-amber-500" />
                            {freelancer.hourly_rate}/hr
                          </div>
                          <p className="text-sm text-gray-500 mt-1">Hourly Rate</p>
                        </div>

                        <Button 
                          onClick={() => handleHire(freelancer)}
                          disabled={!selectedProject || hiring === freelancer.id}
                          className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 w-full py-3"
                        >
                          {hiring === freelancer.id ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                              Hiring...
                            </>
                          ) : (
                            <>
                              <Sparkles className="h-4 w-4 mr-2" />
                              Hire Now
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* No results message */}
        {searching === false && matchedFreelancers.length === 0 && searchParams.description && (
          <Card className="border-0 shadow-md text-center p-12">
            <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <Search className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No matches found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search criteria or required skills</p>
            <Button 
              variant="outline"
              onClick={() => setSearchParams({ description: '', skills: '' })}
            >
              Clear Search
            </Button>
          </Card>
        )}

        {/* Help Card */}
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full flex-shrink-0">
                <Award className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900 mb-2">How Blockchain Hiring Works</h3>
                <ul className="text-blue-800 space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="bg-blue-200 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0">1</span>
                    Select a project and find the perfect freelancer match
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-200 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0">2</span>
                    Click "Hire Now" to deploy a secure smart contract
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-200 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0">3</span>
                    Funds are held in escrow until project completion
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-200 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0">4</span>
                    Payment is automatically released when work is approved
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}