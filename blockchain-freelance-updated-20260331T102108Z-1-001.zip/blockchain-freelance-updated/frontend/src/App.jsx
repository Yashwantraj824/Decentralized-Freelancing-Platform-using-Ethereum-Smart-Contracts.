import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext.jsx';
import { NavigationProvider } from './context/NavigationContext.jsx';
import Layout from './components/layout/Layout';
import HomePage from './components/common/HomePage';
import LoginPage from './components/auth/LoginPage';
import RegisterPage from './components/auth/RegisterPage';
import Dashboard from './components/dashboard/Dashboard';
import PostProjectPage from './components/projects/PostProjectPage';
import FindFreelancersPage from './components/freelancers/FindFreelancersPage';
import WalletPage from './components/common/WalletPage';
import ProfilePage from './components/common/ProfilePage';
import ProjectList from './components/projects/ProjectList';
import { useAuth } from './context/AuthContext.jsx';

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState(user ? 'dashboard' : 'home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home': 
        return <HomePage setCurrentPage={setCurrentPage} />;
      
      case 'login': 
        return <LoginPage setCurrentPage={setCurrentPage} />;
      
      case 'register': 
        return <RegisterPage setCurrentPage={setCurrentPage} />;
      
      case 'dashboard': 
        return <Dashboard />;
      
      case 'post-project':
        return <PostProjectPage setCurrentPage={setCurrentPage} />;
      
      case 'my-projects':
        return (
          <div className="max-w-2xl text-center mx-auto space-y-6">
            <h1 className="text-3xl font-bold mt-5">
              {user?.user_type === 'employer' ? 'My Posted Projects' : 'My Work'}
            </h1>
            <ProjectList userProjects={true} />
          </div>
        );

      case 'available-projects':
        return (
          <div className="max-w-2xl text-center mx-auto space-y-6">
            <h1 className="text-3xl mt-5 font-bold">Browse Open Projects</h1>
            <ProjectList availableProjects={true} showApply={true} />
          </div>
        );
      
      case 'find-freelancers': 
        return <FindFreelancersPage />;
      
      case 'wallet': 
        return <WalletPage />;
      
      case 'profile': 
        return <ProfilePage />;
      
      default: 
        return <HomePage setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <NavigationProvider setCurrentPage={setCurrentPage}>
      <Layout currentPage={currentPage} setCurrentPage={setCurrentPage}>
        {renderPage()}
      </Layout>
    </NavigationProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;