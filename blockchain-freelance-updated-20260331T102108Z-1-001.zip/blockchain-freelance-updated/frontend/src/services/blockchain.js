import Web3 from 'web3';

const CANDIDATE_NAMES = [
  'FreelanceContract.json',
  'FreelanceEscrow.json',
  'FreelanceContractArtifact.json'
];

class BlockchainInterface {
  constructor(providerUrl = import.meta.env.VITE_WEB3_PROVIDER || 'http://127.0.0.1:8545') {
    this.w3 = new Web3(new Web3.providers.HttpProvider(providerUrl));
    this.contractABI = null;
    this.contractBytecode = null;
    this._loadingPromise = null;
    this._artifactName = null;
  }

// inside src/services/blockchain.js -> class BlockchainInterface { ... }
async loadContractData() {
  if (this.contractABI && this.contractBytecode) return;
  if (this._loadingPromise) return this._loadingPromise;

  this._loadingPromise = (async () => {
    let contractData = null;

    // 1) try eager import from src/abi (works with Vite)
    try {
      // will include all JSONs in src/abi at build/dev time
      const modules = import.meta.globEager('/src/abi/*.json');
      const keys = Object.keys(modules);
      if (keys.length) {
        // if you have a preferred artifact name, pick it first
        const preferred = ['FreelanceEscrow.json','FreelanceContract.json','FreelanceContractArtifact.json'];
        let chosenKey = null;
        for (const p of preferred) {
          const candidate = Object.keys(modules).find(k => k.endsWith(`/${p}`));
          if (candidate) { chosenKey = candidate; break; }
        }
        const pick = chosenKey || keys[0];
        contractData = modules[pick].default || modules[pick];
        this._artifactName = pick.split('/').pop();
      }
    } catch (err) {
      // ignore
    }

    // 2) fallback: try fetch from public/contracts or public/abi
    if (!contractData) {
      const CANDIDATE_NAMES = ['FreelanceEscrow.json','FreelanceContract.json','FreelanceContractArtifact.json'];
      const fetchPaths = ['/contracts', '/abi', ''];
      for (const name of CANDIDATE_NAMES) {
        for (const base of fetchPaths) {
          const url = `${base}/${name}`.replace(/\/+/g, '/');
          try {
            const res = await fetch(url, { cache: 'no-store' });
            if (!res.ok) continue;
            const txt = await res.text();
            if (!txt || txt.trim().startsWith('<')) continue;
            try {
              contractData = JSON.parse(txt);
              this._artifactName = name;
              break;
            } catch (_) { continue; }
          } catch (_) { /* ignore */ }
        }
        if (contractData) break;
      }
    }

    if (!contractData) {
      throw new Error('Cannot load contract JSON. Put artifact JSON into src/abi/ or public/contracts/');
    }

    // normalize ABI / bytecode
    this.contractABI = contractData.abi || contractData.abis || contractData.contracts?.[Object.keys(contractData.contracts || {})[0]]?.abi || null;
    this.contractBytecode =
      contractData.bytecode ||
      contractData.evm?.bytecode?.object ||
      contractData.data?.bytecode?.object ||
      contractData.contracts?.[Object.keys(contractData.contracts || {})[0]]?.evm?.bytecode?.object ||
      null;

    if (!this.contractABI || !this.contractBytecode) {
      console.error('artifact keys:', Object.keys(contractData));
      throw new Error('Loaded contract JSON missing ABI or bytecode.');
    }

    console.info(`Loaded contract artifact: ${this._artifactName || '(unknown)'}`);
    return true;
  })();

  return this._loadingPromise;
}


  createWallet() {
    const a = this.w3.eth.accounts.create();
    return { address: this.w3.utils.toChecksumAddress(a.address), privateKey: a.privateKey };
  }

  validateWalletCredentials(walletAddress, privateKey) {
    try {
      const a = this.w3.eth.accounts.privateKeyToAccount(privateKey);
      return a.address.toLowerCase() === walletAddress.toLowerCase();
    } catch { return false; }
  }

  getContract(contractAddress) {
    if (!this.contractABI) throw new Error('Contract ABI not loaded');
    return new this.w3.eth.Contract(this.contractABI, contractAddress);
  }

  // Diagnostic helpers ---------------------------------------------------
  // list ABI methods (call from console)
  async listMethods(contractAddress) {
    await this.loadContractData();
    const c = this.getContract(contractAddress);
    const methods = Object.keys(c.methods || {});
    console.log('ABI methods:', methods);
    return methods;
  }

    // Deploy contract and return deployed address
  async deployContract(employerPrivateKey, freelancerAddress, jobDescription, amountEth = 0) {
      // ensure artifact loaded
      await this.loadContractData();
  
      if (!this.contractBytecode || !this.contractABI) {
        throw new Error('Contract artifact not loaded (ABI/bytecode missing).');
      }
  
      // normalize addresses / inputs
      const freelancer = this.w3.utils.toChecksumAddress(freelancerAddress);
      const account = this.w3.eth.accounts.privateKeyToAccount(employerPrivateKey);
      const from = account.address;
      const amountWei = this.w3.utils.toWei((amountEth || 0).toString(), 'ether');
  
      // create contract deploy tx
      const Contract = new this.w3.eth.Contract(this.contractABI);
      const deploy = Contract.deploy({
        data: this.contractBytecode.startsWith('0x') ? this.contractBytecode : `0x${this.contractBytecode}`,
        arguments: [freelancer, jobDescription]
      });
  
      // estimate gas (best-effort)
      let gas;
      try {
        gas = await deploy.estimateGas({ from, value: amountWei }).catch(() => null);
      } catch (_) { gas = null; }
      if (!gas) gas = 2000000; // fallback
  
      // gas price / nonce
      const gasPrice = await this.w3.eth.getGasPrice();
      const nonce = await this.w3.eth.getTransactionCount(from, 'pending');
  
      const tx = {
        from,
        nonce,
        gas,
        gasPrice,
        data: deploy.encodeABI(),
        value: amountWei
      };
  
      // sign & send
      const signed = await this.w3.eth.accounts.signTransaction(tx, employerPrivateKey);
      const sent = await this.w3.eth.sendSignedTransaction(signed.rawTransaction);
  
      // get contract address from receipt
      if (!sent || !sent.contractAddress) {
        // sometimes receipt is nested; fallback to receipt.contractAddress
        const receipt = sent && sent.events ? sent : sent;
        if (!receipt.contractAddress) {
          throw new Error('Deployment failed: no contractAddress in receipt');
        }
        return receipt.contractAddress;
      }
  
      return sent.contractAddress;
    }
  

  // show on-chain code + artifact prefixes and quick checks
  async diagnoseContract(contractAddress) {
    await this.loadContractData();
    const code = await this.w3.eth.getCode(contractAddress);
    const onChainPrefix = code ? code.slice(0, 200) : '0x';
    const artifactPrefix = this.contractBytecode ? this.contractBytecode.slice(0, 200) : '0x';
    console.groupCollapsed(`diagnoseContract ${contractAddress}`);
    console.log('on-chain code length:', code.length);
    console.log('on-chain code prefix:', onChainPrefix);
    console.log('artifact runtime bytecode length:', this.contractBytecode.length);
    console.log('artifact bytecode prefix:', artifactPrefix);
    console.log('ABI method names:', Object.keys(this.contractABI || {}).length ? Object.keys((new this.w3.eth.Contract(this.contractABI)).methods) : Object.keys(this.contractABI || {}));
    console.groupEnd();
    return { code, onChainPrefix, artifactPrefix };
  }

  // Try call simulation and extract revert reason (robust)
  async _simulateCallAndGetRevertReason(contractAddress, data, from) {
    try {
      await this.w3.eth.call({ to: contractAddress, data, from });
      return null;
    } catch (err) {
      // try parse hex returned payload or message
      let hex = null;
      if (err && typeof err === 'object') {
        if (err.data) {
          if (typeof err.data === 'string' && err.data.startsWith('0x')) hex = err.data;
          else if (typeof err.data === 'object') {
            const first = Object.values(err.data)[0];
            if (first && typeof first === 'object' && first.data) hex = first.data;
            else if (typeof first === 'string' && first.startsWith('0x')) hex = first;
          }
        }
        if (!hex && err.returnedData) {
          const first = Object.values(err.returnedData)[0];
          if (typeof first === 'string' && first.startsWith('0x')) hex = first;
        }
      }
      if (!hex && err && err.message) {
        const m = err.message.match(/(0x[0-9a-fA-F]+)/);
        if (m) hex = m[1];
      }
      if (!hex) return err.message || String(err);

      try {
        const withoutSelector = '0x' + hex.slice(10);
        const decoded = this.w3.eth.abi.decodeParameter('string', withoutSelector);
        return decoded;
      } catch (_) {
        try { return this.w3.utils.hexToAscii(hex).replace(/\u0000/g, '').trim(); }
        catch (_) { return err.message || 'revert'; }
      }
    }
  }

  // central sender with diagnostics on failure
  async _sendContractMethod(contractAddress, methodName, fromPrivateKey, methodArgs = []) {
    await this.loadContractData();
    const contract = this.getContract(contractAddress);

    if (!contract.methods || typeof contract.methods[methodName] !== 'function') {
      // helpful error + diagnostics
      const msg = `Method "${methodName}" not found on ABI. Running diagnoseContract...`;
      console.error(msg);
      try { await this.diagnoseContract(contractAddress); } catch (_) {}
      throw new Error(msg);
    }

    const account = this.w3.eth.accounts.privateKeyToAccount(fromPrivateKey);
    const from = account.address;
    const txMethod = contract.methods[methodName](...methodArgs);
    const data = txMethod.encodeABI();

    // simulation for revert reason
    const revertReason = await this._simulateCallAndGetRevertReason(contractAddress, data, from);
    if (revertReason) {
      // give full diagnostic context
      console.error(`EVM revert detected: ${revertReason}`);
      try {
        const diag = await this.diagnoseContract(contractAddress);
        const codeSnippet = diag.onChainPrefix.slice(0, 200);
        throw new Error(`EVM revert: ${revertReason} | onChainPrefix: ${codeSnippet} | artifactPrefix: ${diag.artifactPrefix.slice(0,200)}`);
      } catch (dErr) {
        throw new Error(`EVM revert: ${revertReason}`);
      }
    }

    // proceed to send
    const gasPrice = await this.w3.eth.getGasPrice();
    let gas;
    try { gas = await txMethod.estimateGas({ from }).catch(() => null); } catch (_) { gas = null; }
    if (!gas) gas = 300000;

    const nonce = await this.w3.eth.getTransactionCount(from);
    const tx = { to: contractAddress, data, gas, gasPrice, nonce };

    try {
      const signed = await this.w3.eth.accounts.signTransaction(tx, fromPrivateKey);
      return await this.w3.eth.sendSignedTransaction(signed.rawTransaction);
    } catch (sendErr) {
      // extra debug info on send failure
      console.error('_sendContractMethod send error:', sendErr);
      try { await this.diagnoseContract(contractAddress); } catch (_) {}
      throw sendErr;
    }
  }

  // Exposed actions
  async startProject(contractAddress, freelancerPrivateKey) {
    return this._sendContractMethod(contractAddress, 'startProject', freelancerPrivateKey, []);
  }

  async completeWork(contractAddress, freelancerPrivateKey) {
    return this._sendContractMethod(contractAddress, 'completeWork', freelancerPrivateKey, []);
  }

  async releasePayment(contractAddress, employerPrivateKey) {
    return this._sendContractMethod(contractAddress, 'releasePayment', employerPrivateKey, []);
  }

  // read helpers
  async getContractStatus(contractAddress) {
    await this.loadContractData();
    const c = this.getContract(contractAddress);
    const [status, balance, employer, freelancer, isCompleted, isPaid] = await Promise.all([
      c.methods.getProjectStatus().call(),
      c.methods.getContractBalance().call(),
      c.methods.employer().call(),
      c.methods.freelancer().call(),
      c.methods.isCompleted().call(),
      c.methods.isPaid().call()
    ]);
    return {
      status,
      balance: this.w3.utils.fromWei(balance, 'ether'),
      employer,
      freelancer,
      is_completed: isCompleted,
      is_paid: isPaid
    };
  }

  async getBalance(address) {
    const checksum = this.w3.utils.toChecksumAddress(address);
    const bal = await this.w3.eth.getBalance(checksum);
    return this.w3.utils.fromWei(bal, 'ether');
  }
}

export default new BlockchainInterface();
