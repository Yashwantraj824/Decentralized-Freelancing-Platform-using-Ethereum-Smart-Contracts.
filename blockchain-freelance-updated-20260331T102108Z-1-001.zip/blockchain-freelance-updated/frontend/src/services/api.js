// src/services/api.js
import axios from 'axios';

class APIService {
  constructor() {
    this.baseURL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
    this.api = axios.create({
      baseURL: this.baseURL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.api.interceptors.request.use(
      (config) => {
        const user = JSON.parse(localStorage.getItem('freelance_user') || '{}');
        if (user && user.token) {
          config.headers.Authorization = `Bearer ${user.token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );
  }

  // --- Helpers ---
  _ensureIntIds(payload = {}) {
    if (!payload || typeof payload !== 'object') return payload;
    const p = { ...payload };
    const idKeys = ['id', 'user_id', 'freelancer_id', 'employer_id', 'project_id', 'contract_id'];
    idKeys.forEach((k) => {
      if (p[k] !== undefined && p[k] !== null) {
        if (typeof p[k] === 'object' && p[k].id !== undefined) {
          p[k] = parseInt(p[k].id, 10);
        } else {
          const n = Number(p[k]);
          if (!Number.isNaN(n)) p[k] = parseInt(n, 10);
        }
      }
    });
    return p;
  }

  _toInt(val) {
    if (val === undefined || val === null) return val;
    if (typeof val === 'object' && val.id !== undefined) return parseInt(val.id, 10);
    const n = Number(val);
    return Number.isNaN(n) ? val : parseInt(n, 10);
  }

  // Basic client-side (weak) hash - demo only
  hashPassword(password) {
    return btoa(password || '');
  }

  // --- Auth ---
  async verifyUser(email, password) {
    try {
      const response = await this.api.post('/auth/verify', {
        email,
        password: this.hashPassword(password),
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Login failed');
    }
  }

  async createUser(userData) {
    try {
      const payload = { ...userData, password: this.hashPassword(userData.password) };
      const response = await this.api.post('/auth/register', payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Registration failed');
    }
  }

  async validateWalletCredentials(walletAddress, privateKey) {
    try {
      const response = await this.api.post('/auth/validate-wallet', {
        wallet_address: walletAddress,
        private_key: privateKey,
      });
      return response.data.valid;
    } catch (error) {
      return false;
    }
  }

  // --- Projects ---
  async getProjects(filters = {}) {
    try {
      // coerce id-like params
      const params = this._ensureIntIds(filters);
      const response = await this.api.get('/projects', { params });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch projects');
    }
  }

  async createProject(projectData) {
    try {
      const payload = this._ensureIntIds(projectData);
      const response = await this.api.post('/projects', payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to create project');
    }
  }

  async updateProject(projectId, updates) {
    try {
      const pid = this._toInt(projectId);
      const payload = this._ensureIntIds(updates);
      const response = await this.api.put(`/projects/${pid}`, payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to update project');
    }
  }

  async deleteProject(projectId) {
    try {
      const pid = this._toInt(projectId);
      const response = await this.api.delete(`/projects/${pid}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to delete project');
    }
  }

  // --- Freelancers ---
  async getAllFreelancers() {
    try {
      const response = await this.api.get('/freelancers');
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch freelancers');
    }
  }

  async getFreelancerProfile(userId) {
    try {
      const uid = this._toInt(userId);
      const response = await this.api.get(`/freelancers/profile/${uid}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to fetch freelancer profile');
    }
  }

  async createFreelancerProfile(profileData) {
    try {
      const payload = this._ensureIntIds(profileData);
      if (!payload.user_id && payload.user && payload.user.id) {
        payload.user_id = parseInt(payload.user.id, 10);
        delete payload.user;
      }
      // ensure user_id present if available in localStorage
      if (!payload.user_id) {
        const stored = JSON.parse(localStorage.getItem('freelance_user') || '{}');
        if (stored?.id) payload.user_id = parseInt(stored.id, 10);
      }
      const response = await this.api.post('/freelancers/profile', payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to create freelancer profile');
    }
  }

  async updateFreelancerProfile(userId, profileData) {
    try {
      const uid = this._toInt(userId);
      const payload = this._ensureIntIds(profileData);
      const response = await this.api.put(`/freelancers/profile/${uid}`, payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to update freelancer profile');
    }
  }

  async matchFreelancers(projectDescription, requiredSkills) {
    try {
      const response = await this.api.post('/freelancers/match', {
        project_description: projectDescription,
        required_skills: requiredSkills,
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to match freelancers');
    }
  }

  // --- Blockchain endpoints ---
  async deployContract(contractData) {
    try {
      // contractData should contain employer_private_key, freelancer_address, job_description, amount
      const payload = { ...contractData };
      // coerce numeric/ids
      if (payload.amount !== undefined) payload.amount = Number(payload.amount);
      const response = await this.api.post('/blockchain/deploy', payload);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to deploy contract');
    }
  }

  async executeContractAction(contractAddress, action, privateKey, additionalData = {}) {
    try {
      const response = await this.api.post('/blockchain/execute', {
        contract_address: contractAddress,
        action,
        private_key: privateKey,
        ...additionalData,
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Contract execution failed');
    }
  }

  async getContractStatus(contractAddress) {
    try {
      const response = await this.api.get(`/blockchain/status/${contractAddress}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to get contract status');
    }
  }
  async ensureProjectContract(projectId) {
    try {
      const response = await this.api.post(`/projects/${projectId}/deploy`);
      return response.data; // { contract_address: "0x..." }
    } catch (error) {
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to ensure contract');
    }
  }

  // --- Wallet ---
  async getWalletBalance(address) {
    try {
      const response = await this.api.get(`/wallet/balance/${address}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to get wallet balance');
    }
  }

  // --- File Upload ---
  async uploadCompletionFiles(projectId, files, notes) {
    try {
      const formData = new FormData();

      // Add files to form data
      if (files && files.length > 0) {
        for (let i = 0; i < files.length; i++) {
          formData.append('files', files[i]);
        }
      }

      // Add notes if provided
      if (notes) {
        formData.append('notes', notes);
      }

      const response = await this.api.post(
        `/projects/${projectId}/upload-completion-files`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to upload files');
    }
  }

  async getCompletionFiles(projectId) {
    try {
      const response = await this.api.get(`/projects/${projectId}/completion-files`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to retrieve completion files');
    }
  }

  getFileDownloadUrl(projectId, filename) {
    return `${this.baseURL}/projects/${projectId}/files/${filename}`;
  }

  // ============ MESSAGING METHODS ============

  // Get message history for a project
  async getProjectMessages(projectId, userId = null) {
    try {
      const params = userId ? { user_id: userId } : {};
      const response = await this.api.get(`/messages/${projectId}`, { params });
      return response.data;
    } catch (error) {
      console.error('Failed to get messages:', error);
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to get messages');
    }
  }

  // Get unread message counts for a user
  async getUnreadMessageCounts(userId) {
    try {
      const response = await this.api.get(`/messages/unread/${userId}`);
      return response.data;
    } catch (error) {
      console.error('Failed to get unread counts:', error);
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to get unread counts');
    }
  }

  // Upload message file attachment
  async uploadMessageFile(projectId, file) {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await this.api.post(`/messages/${projectId}/upload-file`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      console.error('Failed to upload message file:', error);
      throw new Error(error.response?.data?.detail || error.response?.data?.message || 'Failed to upload file');
    }
  }

  // Get message file download URL
  getMessageFileUrl(filename) {
    // Extract project_id and filename from the file_url pattern: /messages/{project_id}/files/{filename}
    return `${this.baseURL}${filename}`;
  }

  // Upload project reference media
  async uploadProjectMedia(projectId, files) {
    try {
      const formData = new FormData();
      for (let i = 0; i < files.length; i++) {
        formData.append('files', files[i]);
      }
      const response = await this.api.post(`/projects/${projectId}/upload-media`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Failed to upload media');
    }
  }

  async getProjectMedia(projectId) {
    try {
      const response = await this.api.get(`/projects/${projectId}/media`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Failed to get media');
    }
  }

  getProjectMediaUrl(projectId, filename) {
    return `${this.baseURL}/projects/${projectId}/media/${filename}`;
  }

  async requestRedo(projectId, note) {
    try {
      const response = await this.api.post(`/projects/${projectId}/request-redo`, { note });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Failed to request redo');
    }
  }

  async cancelProject(projectId, reason) {
    try {
      const response = await this.api.post(`/projects/${projectId}/cancel`, { reason });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Failed to cancel project');
    }
  }

  // Get WebSocket URL
  getWebSocketUrl(projectId, userId) {
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsHost = this.baseURL.replace('http://', '').replace('https://', '');
    return `${wsProtocol}//${wsHost}/ws/chat/${projectId}/${userId}`;
  }
}

export default new APIService();
