# Messaging System Guide

## Overview
The messaging system allows employers and freelancers to communicate in real-time within project contexts using WebSocket technology.

## Features Implemented

### 1. **Real-time Chat**
- Instant message delivery using WebSockets
- Messages appear without page refresh
- Auto-reconnection if connection is lost

### 2. **File Attachments**
- Send images, PDFs, documents in chat
- Max file size: 10MB
- Download attachments directly from chat

### 3. **Unread Message Indicators**
- Red badge shows unread message count on Chat button
- Automatically marks messages as read when viewing chat
- Updates every 30 seconds

### 4. **Project-Specific Communication**
- Chat only available for assigned projects
- Both employer and freelancer can access chat
- Chat accessible from project card

## How to Use

### For Employers:
1. Post a project
2. Hire a freelancer
3. Once project is assigned, "Chat" button appears on project card
4. Click "Chat" button to open messaging window
5. Send messages or attach files to communicate

### For Freelancers:
1. Apply to a project
2. Get hired by employer
3. "Chat" button appears once project is assigned
4. Click "Chat" to discuss project details
5. Upload deliverables or ask questions

## Technical Details

### Backend (appf.py)
- **Database Table**: `messages` table stores all chat history
- **WebSocket Endpoint**: `/ws/chat/{project_id}/{user_id}`
- **REST Endpoints**:
  - `GET /messages/{project_id}` - Get message history
  - `GET /messages/unread/{user_id}` - Get unread counts
  - `POST /messages/{project_id}/upload-file` - Upload file attachment

### Frontend Components
- **ChatComponent.jsx**: Main chat UI with WebSocket connection
- **API Service**: Methods for messaging in `api.js`
- **ProjectList.jsx**: Integrated chat button and unread indicators

## Testing the System

### Step 1: Start Backend
```bash
cd "/home/sk/workspace/qriocity/Blockchain/blockchain based freelancing"
python appf.py
```

### Step 2: Start Frontend
```bash
cd frontend
npm run dev
```

### Step 3: Test Messaging
1. Open two browser windows/tabs (or use incognito mode)
2. In Window 1: Login as Employer
   - Post a project
   - Hire a freelancer

3. In Window 2: Login as Freelancer (the one who was hired)
   - Go to "My Projects"
   - Find the assigned project

4. In both windows:
   - Click "Chat" button on the project
   - Send messages back and forth
   - Test file attachments
   - Verify real-time delivery

### Step 4: Test Features
- [ ] Send text messages
- [ ] Send file attachments
- [ ] Check unread indicators
- [ ] Test auto-reconnection (stop/start backend)
- [ ] Verify message history persists

## File Locations

### Backend Files Modified:
- `appf.py` - Added WebSocket support, messaging endpoints, database table

### Frontend Files Created/Modified:
- `frontend/src/components/common/ChatComponent.jsx` - NEW
- `frontend/src/services/api.js` - Added messaging methods
- `frontend/src/components/projects/ProjectList.jsx` - Added chat button & modal

### Database:
- New table: `messages`
  - Columns: id, project_id, sender_id, message_text, file_url, file_name, is_read, created_at

## Troubleshooting

### Messages not appearing?
- Check WebSocket connection status (green/red indicator)
- Verify backend is running on port 8000
- Check browser console for errors

### Files not uploading?
- Ensure file is under 10MB
- Check supported formats: images, PDF, DOC, DOCX, TXT
- Verify uploads/messages directory exists

### Connection keeps dropping?
- Backend may have stopped
- Check firewall settings
- Verify WebSocket URL in browser console

## Next Steps (Optional Enhancements)

Future improvements you could add:
1. **Typing indicators** - Show when other person is typing
2. **Read receipts** - Show when messages are read
3. **Email notifications** - Notify users of new messages via email
4. **Message search** - Search through chat history
5. **Emoji support** - Add emoji picker
6. **Voice messages** - Record and send voice notes
7. **Video calls** - Integrate WebRTC for video conferencing

## Support

If you encounter any issues:
1. Check browser console (F12) for errors
2. Check backend logs for WebSocket connection issues
3. Verify database has messages table created
4. Ensure CORS settings allow WebSocket connections
